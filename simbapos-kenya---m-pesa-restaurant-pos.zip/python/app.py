#!/usr/bin/env python3
"""
SimbaPOS Python Microservice Backend
Provides a lightweight standalone HTTP API for M-Pesa STK Push and Digital Receipts.
Can be run on port 5000: `python3 python/app.py`
"""

import json
from http.server import HTTPServer, BaseHTTPRequestHandler
import urllib.parse
from mpesa_service import MpesaDarajaService
from receipt_printer import KenyaReceiptPrinter

mpesa_service = MpesaDarajaService()
receipt_printer = KenyaReceiptPrinter()

class POSApiHandler(BaseHTTPRequestHandler):
    def _set_headers(self, status=200):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type, Authorization')
        self.end_headers()

    def do_OPTIONS(self):
        self._set_headers(200)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if path == "/api/health":
            self._set_headers(200)
            self.wfile.write(json.dumps({
                "status": "online",
                "service": "SimbaPOS Python M-Pesa Engine",
                "python_version": "3.10+",
                "daraja_env": mpesa_service.env
            }).encode())
        elif path == "/api/mpesa/query":
            checkout_id = query.get("checkout_id", [""])[0]
            res = mpesa_service.query_stk_status(checkout_id)
            self._set_headers(200)
            self.wfile.write(json.dumps(res).encode())
        else:
            self._set_headers(404)
            self.wfile.write(json.dumps({"error": "Endpoint not found"}).encode())

    def do_POST(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length).decode('utf-8')
        data = json.loads(body) if body else {}

        if path == "/api/mpesa/stkpush":
            phone = data.get("phone", "254712345678")
            amount = int(data.get("amount", 100))
            account = data.get("account", "Simba Restaurant")
            res = mpesa_service.initiate_stk_push(phone, amount, account)
            self._set_headers(200)
            self.wfile.write(json.dumps(res).encode())

        elif path == "/api/mpesa/c2b-verify":
            code = data.get("code", "")
            res = mpesa_service.verify_c2b_code(code)
            self._set_headers(200)
            self.wfile.write(json.dumps(res).encode())

        elif path == "/api/receipt/generate":
            order = data.get("order", {})
            tax = receipt_printer.calculate_taxes(
                sum(i.get("price", 0) * i.get("quantity", 1) for i in order.get("items", []))
            )
            res = {
                "order": order,
                "taxes": tax,
                "ascii": receipt_printer.generate_ascii_thermal(order),
                "whatsapp": receipt_printer.generate_whatsapp_format(order),
                "sms": receipt_printer.generate_sms_format(order)
            }
            self._set_headers(200)
            self.wfile.write(json.dumps(res).encode())

        else:
            self._set_headers(404)
            self.wfile.write(json.dumps({"error": "Endpoint not found"}).encode())

def run(port=5000):
    server_address = ('', port)
    httpd = HTTPServer(server_address, POSApiHandler)
    print(f"SimbaPOS Python Microservice running on port {port}...")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    httpd.server_close()

if __name__ == "__main__":
    run()
