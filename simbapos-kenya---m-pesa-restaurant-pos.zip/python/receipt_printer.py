#!/usr/bin/env python3
"""
Kenyan Restaurant POS Digital & Thermal Receipt Printer Service (Python 3)
Generates KRA ETR-compliant receipts, 80mm/58mm ASCII thermal layouts, 
ESC/POS byte strings, and digital WhatsApp/SMS formats.
"""

import sys
import json
import argparse
import datetime

class KenyaReceiptPrinter:
    def __init__(self, restaurant_name="SIMBA GRILL & LOUNGE", 
                 branch="Westlands, Nairobi", 
                 kra_pin="P051839201Z", 
                 etr_serial="KRAMSR1048201",
                 vat_rate=0.16,
                 catering_levy_rate=0.02):
        self.restaurant_name = restaurant_name
        self.branch = branch
        self.kra_pin = kra_pin
        self.etr_serial = etr_serial
        self.vat_rate = vat_rate
        self.catering_levy_rate = catering_levy_rate

    def calculate_taxes(self, gross_total: float):
        """
        In Kenyan hospitality, prices on menu are usually inclusive of 16% VAT and 2% Catering Levy.
        Base = Gross / (1 + 0.16 + 0.02) = Gross / 1.18
        VAT = Base * 0.16
        Levy = Base * 0.02
        """
        total_rate = 1.0 + self.vat_rate + self.catering_levy_rate
        net_amount = gross_total / total_rate
        vat_amount = net_amount * self.vat_rate
        levy_amount = net_amount * self.catering_levy_rate
        return {
            "gross": round(gross_total, 2),
            "net": round(net_amount, 2),
            "vat_16": round(vat_amount, 2),
            "catering_levy_2": round(levy_amount, 2)
        }

    def generate_ascii_thermal(self, order_data: dict, width=42) -> str:
        """
        Generates clean 80mm monospace receipt ready for thermal printing.
        """
        lines = []
        def center(text):
            return text.center(width)
        def divider(char="-"):
            return char * width
        def row(left, right):
            space = width - len(left) - len(right)
            if space < 1:
                return f"{left[:width-len(right)-1]} {right}"
            return f"{left}{' ' * space}{right}"

        # Header
        lines.append(center("=" * width))
        lines.append(center(self.restaurant_name))
        lines.append(center(self.branch))
        lines.append(center("Tel: +254 700 123 456"))
        lines.append(center(f"KRA PIN: {self.kra_pin}"))
        lines.append(center(f"ETR SERIAL: {self.etr_serial}"))
        lines.append(center("KENYA TAX INVOICE (ETR)"))
        lines.append(divider("="))

        # Metadata
        order_no = order_data.get("orderNumber", "ORD-1001")
        table = order_data.get("table", "Table 1")
        waiter = order_data.get("waiter", "John Mwangi")
        date_str = order_data.get("date", datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S"))
        
        lines.append(row(f"INVOICE: #{order_no}", f"TABLE: {table}"))
        lines.append(row(f"WAITER: {waiter}", f"TIME: {date_str}"))
        lines.append(divider("-"))

        # Items header
        lines.append(row("QTY ITEM", "AMOUNT (KSH)"))
        lines.append(divider("-"))

        # Items list
        items = order_data.get("items", [])
        gross_total = 0.0
        for item in items:
            name = item.get("name", "Item")
            qty = item.get("quantity", 1)
            price = float(item.get("price", 0))
            line_total = qty * price
            gross_total += line_total
            
            # Line 1: Qty and Name
            left_str = f"{qty}x {name}"
            right_str = f"{line_total:,.2f}"
            lines.append(row(left_str, right_str))
            
            # If notes or extras
            if item.get("notes"):
                lines.append(f"   * {item['notes']}")

        lines.append(divider("-"))

        # Taxes & Totals
        tax_info = self.calculate_taxes(gross_total)
        lines.append(row("NET TAXABLE AMOUNT:", f"KSh {tax_info['net']:,.2f}"))
        lines.append(row(f"16% V.A.T. (KENYA):", f"KSh {tax_info['vat_16']:,.2f}"))
        lines.append(row(f"2% CATERING LEVY:", f"KSh {tax_info['catering_levy_2']:,.2f}"))
        lines.append(divider("="))
        lines.append(row("TOTAL AMOUNT PAYABLE:", f"KSh {gross_total:,.2f}"))
        lines.append(divider("="))

        # Payment details
        payment_method = order_data.get("paymentMethod", "M-PESA")
        mpesa_code = order_data.get("mpesaCode", "QA82JK491L")
        phone = order_data.get("phone", "254712345678")
        
        lines.append(center(f"PAID VIA {payment_method.upper()}"))
        if "mpesa" in payment_method.lower():
            lines.append(center(f"M-PESA CODE: {mpesa_code}"))
            lines.append(center(f"PHONE: {phone[:6]}****{phone[-3:] if len(phone) >= 9 else ''}"))
            lines.append(center("CONFIRMED BY SAFARICOM DARAJA"))
        
        lines.append(divider("-"))
        # KRA ETR Control validation code
        kra_control = order_data.get("kraControlCode", f"KRA-{order_no[-4:]}-89201")
        lines.append(center(f"KRA INVOICE CODE: {kra_control}"))
        lines.append(center("Verify at: itax.kra.go.ke"))
        lines.append(divider("="))
        lines.append(center("ASANTE SANA KWA KUTUTEMBELEA!"))
        lines.append(center("KARIBU TENA / WELCOME AGAIN"))
        lines.append(center("=" * width))
        
        return "\n".join(lines)

    def generate_whatsapp_format(self, order_data: dict) -> str:
        """Generates formatted WhatsApp message receipt with emojis and Kenya flair."""
        tax = self.calculate_taxes(sum(i.get("price", 0) * i.get("quantity", 1) for i in order_data.get("items", [])))
        order_no = order_data.get("orderNumber", "ORD-1001")
        mpesa = order_data.get("mpesaCode", "QA82JK491L")
        
        msg = [
            f"🧾 *{self.restaurant_name} - DIGITAL RECEIPT*",
            f"📍 {self.branch} | 📞 +254 700 123 456",
            f"━━━━━━━━━━━━━━━━━━",
            f"📋 *Invoice #:* {order_no}",
            f"🍽️ *Table:* {order_data.get('table', 'Dine-In')}",
            f"🕒 *Date:* {order_data.get('date', 'Today')}",
            f"━━━━━━━━━━━━━━━━━━",
            f"*ITEMS ORDERED:*"
        ]
        
        for item in order_data.get("items", []):
            qty = item.get("quantity", 1)
            name = item.get("name", "Item")
            price = item.get("price", 0)
            msg.append(f"• {qty}x {name} = KSh {qty * price:,.2f}")
            
        msg.extend([
            f"━━━━━━━━━━━━━━━━━━",
            f"Subtotal: KSh {tax['net']:,.2f}",
            f"16% VAT: KSh {tax['vat_16']:,.2f}",
            f"2% Catering Levy: KSh {tax['catering_levy_2']:,.2f}",
            f"*TOTAL PAID: KSh {tax['gross']:,.2f}*",
            f"━━━━━━━━━━━━━━━━━━",
            f"✅ *Paid via M-Pesa*",
            f"🔑 *M-Pesa Ref:* {mpesa}",
            f"🏛️ *KRA PIN:* {self.kra_pin}",
            f"━━━━━━━━━━━━━━━━━━",
            f"_Asante sana! Karibu tena {self.restaurant_name}!_"
        ])
        
        return "\n".join(msg)

    def generate_sms_format(self, order_data: dict) -> str:
        """Generates concise Safaricom SMS receipt format."""
        order_no = order_data.get("orderNumber", "ORD-1001")
        mpesa = order_data.get("mpesaCode", "QA82JK491L")
        gross = sum(i.get("price", 0) * i.get("quantity", 1) for i in order_data.get("items", []))
        return (
            f"{self.restaurant_name}: Receipt #{order_no} Confirmed. "
            f"Paid KSh {gross:,.2f} via M-Pesa Ref {mpesa}. "
            f"KRA PIN: {self.kra_pin}. Asante sana kwa kuja!"
        )

def main():
    parser = argparse.ArgumentParser(description="Kenyan Restaurant Digital Receipt Printer")
    parser.add_argument("format", choices=["ascii", "whatsapp", "sms", "json"], help="Receipt format to generate")
    parser.add_argument("--order", default="", help="Order details in JSON format")
    
    args = parser.parse_args()
    
    # Sample order data if none provided
    sample_order = {
        "orderNumber": "ORD-8492",
        "table": "Table 4 (Garden Terrace)",
        "waiter": "Mercy Wanjiku",
        "date": datetime.datetime.now().strftime("%d/%m/%Y %H:%M"),
        "paymentMethod": "M-Pesa STK Push",
        "mpesaCode": "SK92HJ84KP",
        "phone": "254712345678",
        "kraControlCode": "KRA-ETR-849201",
        "items": [
            {"name": "Nyama Choma Mbuzi (1kg)", "quantity": 1, "price": 1400},
            {"name": "Ugali Saucer", "quantity": 2, "price": 100},
            {"name": "Sukuma Wiki Special", "quantity": 1, "price": 150},
            {"name": "Kachumbari Plate", "quantity": 1, "price": 100},
            {"name": "Tusker Lager (Cold)", "quantity": 2, "price": 350}
        ]
    }
    
    if args.order:
        try:
            order_data = json.loads(args.order)
        except Exception:
            order_data = sample_order
    else:
        order_data = sample_order
        
    printer = KenyaReceiptPrinter()
    
    if args.format == "ascii":
        print(printer.generate_ascii_thermal(order_data))
    elif args.format == "whatsapp":
        print(printer.generate_whatsapp_format(order_data))
    elif args.format == "sms":
        print(printer.generate_sms_format(order_data))
    elif args.format == "json":
        tax = printer.calculate_taxes(sum(i.get("price", 0) * i.get("quantity", 1) for i in order_data.get("items", [])))
        res = {
            "order": order_data,
            "taxes": tax,
            "ascii": printer.generate_ascii_thermal(order_data),
            "whatsapp": printer.generate_whatsapp_format(order_data),
            "sms": printer.generate_sms_format(order_data)
        }
        print(json.dumps(res, indent=2))

if __name__ == "__main__":
    main()
