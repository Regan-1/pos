import React, { useState, useEffect } from 'react';
import { MenuItem, StaffMember, Order, RestaurantSettings } from './types';
import { Header } from './components/Header';
import { PosTerminal } from './components/PosTerminal';
import { KitchenOrders } from './components/KitchenOrders';
import { ReceiptsList } from './components/ReceiptsList';
import { MpesaPythonHub } from './components/MpesaPythonHub';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { StaffManagement } from './components/StaffManagement';
import { MpesaModal } from './components/MpesaModal';
import { ReceiptModal } from './components/ReceiptModal';
import { StaffSwitchModal } from './components/StaffSwitchModal';
import { posAudio } from './utils/audio';

// Default Fallback Settings
const defaultSettings: RestaurantSettings = {
  restaurantName: 'SIMBA GRILL & LOUNGE',
  tagline: 'Authentic Kenyan Choma & Swahili Flavours',
  branch: 'Westlands, Nairobi, Kenya',
  telephone: '+254 700 123 456',
  kraPin: 'P051839201Z',
  etrSerial: 'KRAMSR1048201',
  mpesaShortcode: '174379',
  mpesaTill: '849201',
  mpesaPaybill: '522522',
  mpesaPasskey: 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919',
  mpesaConsumerKey: 'SANDBOX_DEMO_KEY_DARAJA_KENYA',
  mpesaConsumerSecret: 'SANDBOX_DEMO_SECRET_DARAJA_KENYA',
  environment: 'sandbox',
  vatRate: 0.16,
  cateringLevyRate: 0.02
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'pos' | 'kitchen' | 'receipts' | 'mpesa' | 'analytics' | 'staff'>('pos');
  const [menu, setMenu] = useState<MenuItem[]>([]);
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [callbacks, setCallbacks] = useState<any[]>([]);
  const [settings, setSettings] = useState<RestaurantSettings>(defaultSettings);
  const [currentStaff, setCurrentStaff] = useState<StaffMember | null>(null);

  // Modals
  const [activeMpesaOrder, setActiveMpesaOrder] = useState<Partial<Order> | null>(null);
  const [activeReceiptOrder, setActiveReceiptOrder] = useState<Order | null>(null);
  const [isStaffModalOpen, setIsStaffModalOpen] = useState(false);

  // Fetch initial data
  useEffect(() => {
    fetch('/api/pos/initial-data')
      .then(res => res.json())
      .then(data => {
        if (data.menu) setMenu(data.menu);
        if (data.staff) {
          setStaff(data.staff);
          if (!currentStaff && data.staff.length > 0) {
            setCurrentStaff(data.staff[0]);
          }
        }
        if (data.orders) setOrders(data.orders);
        if (data.settings) setSettings(data.settings);
        if (data.mpesaCallbacks) setCallbacks(data.mpesaCallbacks);
      })
      .catch(() => {
        // Fallback handled by local state
      });
  }, []);

  // Save / Update order on server and local state
  const saveOrder = async (orderData: Partial<Order>) => {
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(orderData)
      });
      const data = await res.json();
      if (data.order) {
        setOrders(prev => {
          const idx = prev.findIndex(o => o.id === data.order.id);
          if (idx >= 0) {
            const updated = [...prev];
            updated[idx] = data.order;
            return updated;
          }
          return [data.order, ...prev];
        });
      }
    } catch {
      // Local fallback
      setOrders(prev => {
        const fullOrder = orderData as Order;
        const idx = prev.findIndex(o => o.id === fullOrder.id);
        if (idx >= 0) {
          const updated = [...prev];
          updated[idx] = fullOrder;
          return updated;
        }
        return [fullOrder, ...prev];
      });
    }
  };

  // Open M-Pesa Modal
  const handleOpenMpesaPay = (order: Partial<Order>) => {
    setActiveMpesaOrder(order);
  };

  // Payment Success handler
  const handlePaymentSuccess = (paidOrder: Order) => {
    saveOrder(paidOrder);
    setActiveMpesaOrder(null);
    setActiveReceiptOrder(paidOrder); // automatically pop up the digital receipt!
  };

  // Send to kitchen
  const handleSendToKitchen = (order: Partial<Order>) => {
    posAudio.playClick();
    saveOrder(order);
  };

  // Direct cash or card checkout
  const handleDirectCheckout = (order: Partial<Order>, method: 'cash' | 'card') => {
    posAudio.playCashRegister();
    const settledOrder: Order = {
      ...(order as Order),
      status: 'paid',
      paymentMethod: method,
      paidAt: new Date().toISOString(),
      kraControlCode: `KRA-ETR-${order.orderNumber?.replace('ORD-', '') || '8492'}${Math.floor(10 + Math.random() * 90)}`
    };
    saveOrder(settledOrder);
    setActiveReceiptOrder(settledOrder);
  };

  // Update order status in KDS
  const handleUpdateOrderStatus = (orderId: string, newStatus: Order['status']) => {
    posAudio.playClick();
    const order = orders.find(o => o.id === orderId);
    if (order) {
      const updated = { ...order, status: newStatus };
      saveOrder(updated);
    }
  };

  // Staff shift updates
  const handleUpdateShift = async (staffId: string, action: 'clock_in' | 'clock_out' | 'break') => {
    posAudio.playClick();
    try {
      const res = await fetch('/api/staff/shift', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ staffId, action })
      });
      const data = await res.json();
      if (data.staff) {
        setStaff(prev => prev.map(s => s.id === staffId ? data.staff : s));
        if (currentStaff?.id === staffId) {
          setCurrentStaff(data.staff);
        }
      }
    } catch {
      // Local fallback
      setStaff(prev => prev.map(s => {
        if (s.id === staffId) {
          return {
            ...s,
            status: action === 'clock_in' ? 'active' : action === 'break' ? 'on_break' : 'clocked_out'
          };
        }
        return s;
      }));
    }
  };

  // Add staff
  const handleAddStaff = async (newStaffData: Partial<StaffMember>) => {
    try {
      const res = await fetch('/api/staff', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newStaffData)
      });
      const data = await res.json();
      if (data.staff) {
        setStaff(data.staff);
      }
    } catch {
      const created: StaffMember = {
        id: `s${Date.now()}`,
        name: newStaffData.name || 'New Staff',
        phone: newStaffData.phone || '0700000000',
        role: newStaffData.role || 'waiter',
        pin: newStaffData.pin || '1234',
        commissionRate: newStaffData.commissionRate || 2.5,
        totalSalesKSh: 0,
        tablesServed: 0,
        status: 'active'
      };
      setStaff(prev => [...prev, created]);
    }
  };

  // Update Settings
  const handleUpdateSettings = async (newSettings: Partial<RestaurantSettings>) => {
    try {
      const res = await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newSettings)
      });
      const data = await res.json();
      if (data.settings) {
        setSettings(data.settings);
      }
    } catch {
      setSettings(prev => ({ ...prev, ...newSettings }));
    }
  };

  const pendingCount = orders.filter(o => o.status === 'pending' || o.status === 'preparing').length;

  const activeStaffMember = currentStaff || staff[0] || {
    id: 's1',
    name: 'Mercy Wanjiku',
    phone: '0712345678',
    role: 'cashier',
    pin: '1234',
    status: 'active',
    commissionRate: 2.0,
    totalSalesKSh: 84200,
    tablesServed: 38
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans">
      
      {/* Top Header Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentStaff={activeStaffMember}
        onSwitchStaff={() => setIsStaffModalOpen(true)}
        pendingOrderCount={pendingCount}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTab === 'pos' && (
          <PosTerminal
            menu={menu}
            currentStaff={activeStaffMember}
            onOpenMpesaPay={handleOpenMpesaPay}
            onSendToKitchen={handleSendToKitchen}
            onDirectCheckout={handleDirectCheckout}
          />
        )}

        {activeTab === 'kitchen' && (
          <KitchenOrders
            orders={orders}
            onUpdateOrderStatus={handleUpdateOrderStatus}
            onOpenMpesaPay={handleOpenMpesaPay}
            onViewReceipt={(order) => setActiveReceiptOrder(order)}
          />
        )}

        {activeTab === 'receipts' && (
          <ReceiptsList
            orders={orders}
            settings={settings}
            onOpenReceiptModal={(order) => setActiveReceiptOrder(order)}
          />
        )}

        {activeTab === 'mpesa' && (
          <MpesaPythonHub
            settings={settings}
            onUpdateSettings={handleUpdateSettings}
            callbacks={callbacks}
          />
        )}

        {activeTab === 'analytics' && (
          <AnalyticsDashboard
            orders={orders}
            settings={settings}
          />
        )}

        {activeTab === 'staff' && (
          <StaffManagement
            staffList={staff}
            currentStaff={activeStaffMember}
            onUpdateShift={handleUpdateShift}
            onAddStaff={handleAddStaff}
            onSelectCurrentStaff={(member) => setCurrentStaff(member)}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-neutral-800/80 bg-neutral-950 py-4 px-4 text-xs text-neutral-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-neutral-300">{settings.restaurantName}</span>
            <span>·</span>
            <span>KRA ETR PIN: {settings.kraPin}</span>
            <span>·</span>
            <span>M-Pesa Shortcode: {settings.mpesaShortcode}</span>
          </div>
          <div className="flex items-center gap-2 text-[11px] font-mono text-neutral-400">
            <span>Safaricom Daraja 2.0</span>
            <span>·</span>
            <span className="text-emerald-400">Python 3.10 Powered</span>
          </div>
        </div>
      </footer>

      {/* M-Pesa Payment Checkout Modal */}
      {activeMpesaOrder && (
        <MpesaModal
          order={activeMpesaOrder}
          isOpen={!!activeMpesaOrder}
          onClose={() => setActiveMpesaOrder(null)}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* Digital & Thermal Receipt Printer Modal */}
      {activeReceiptOrder && (
        <ReceiptModal
          order={activeReceiptOrder}
          settings={settings}
          isOpen={!!activeReceiptOrder}
          onClose={() => setActiveReceiptOrder(null)}
        />
      )}

      {/* Staff PIN Switch Modal */}
      {isStaffModalOpen && (
        <StaffSwitchModal
          staffList={staff}
          isOpen={isStaffModalOpen}
          onClose={() => setIsStaffModalOpen(false)}
          onSelectStaff={(selected) => setCurrentStaff(selected)}
        />
      )}

    </div>
  );
}
