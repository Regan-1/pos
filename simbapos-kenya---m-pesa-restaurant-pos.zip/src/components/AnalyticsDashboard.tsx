import React, { useState } from 'react';
import { Order, RestaurantSettings } from '../types';
import { BarChart3, TrendingUp, DollarSign, Smartphone, Download, Calendar, ShieldCheck, PieChart, ArrowUpRight } from 'lucide-react';

interface AnalyticsDashboardProps {
  orders: Order[];
  settings: RestaurantSettings;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  orders,
  settings
}) => {
  const [timeRange, setTimeRange] = useState<'today' | 'week' | 'month'>('today');

  const paidOrders = orders.filter(o => o.status === 'paid');

  // Total Gross Revenue
  const totalRevenue = paidOrders.reduce((sum, o) => sum + (o.total || 0), 0);
  const totalNet = totalRevenue / 1.18;
  const totalVat = totalNet * 0.16;
  const totalLevy = totalNet * 0.02;
  const aov = paidOrders.length > 0 ? Math.round(totalRevenue / paidOrders.length) : 0;

  // Payment methods breakdown
  const mpesaStkTotal = paidOrders.filter(o => o.paymentMethod === 'mpesa_stk').reduce((sum, o) => sum + o.total, 0);
  const mpesaC2bTotal = paidOrders.filter(o => o.paymentMethod === 'mpesa_c2b').reduce((sum, o) => sum + o.total, 0);
  const cashTotal = paidOrders.filter(o => o.paymentMethod === 'cash').reduce((sum, o) => sum + o.total, 0);
  const cardTotal = paidOrders.filter(o => o.paymentMethod === 'card').reduce((sum, o) => sum + o.total, 0);

  const mpesaTotal = mpesaStkTotal + mpesaC2bTotal;
  const mpesaPercent = totalRevenue > 0 ? Math.round((mpesaTotal / totalRevenue) * 100) : 0;

  // Item bestsellers count
  const itemMap: { [name: string]: { qty: number; sales: number } } = {};
  paidOrders.forEach(o => {
    o.items.forEach(i => {
      if (!itemMap[i.name]) itemMap[i.name] = { qty: 0, sales: 0 };
      itemMap[i.name].qty += i.quantity;
      itemMap[i.name].sales += i.quantity * i.price;
    });
  });

  const bestSellers = Object.entries(itemMap)
    .map(([name, data]) => ({ name, ...data }))
    .sort((a, b) => b.sales - a.sales)
    .slice(0, 5);

  // Hourly rush mock profile based on real Kenyan dining hours
  const hourlyData = [
    { hour: '11:00', label: '11 AM', sales: 4200, count: 2 },
    { hour: '12:00', label: '12 PM', sales: 18500, count: 8 },
    { hour: '13:00', label: '1 PM', sales: 34200, count: 14 }, // Lunch rush
    { hour: '14:00', label: '2 PM', sales: 21000, count: 9 },
    { hour: '15:00', label: '3 PM', sales: 6500, count: 3 },
    { hour: '16:00', label: '4 PM', sales: 9400, count: 4 },
    { hour: '17:00', label: '5 PM', sales: 16800, count: 7 },
    { hour: '18:00', label: '6 PM', sales: 38900, count: 16 }, // Evening Choma rush starts
    { hour: '19:00', label: '7 PM', sales: 52400, count: 22 },
    { hour: '20:00', label: '8 PM', sales: 61200, count: 25 },
    { hour: '21:00', label: '9 PM', sales: 44000, count: 18 },
    { hour: '22:00', label: '10 PM', sales: 19800, count: 8 }
  ];

  const maxHourSales = Math.max(...hourlyData.map(h => h.sales));

  // CSV Export for KRA Tax Ledger & Restaurant Accounting
  const exportCsv = () => {
    const headers = ['Order Number', 'Date', 'Table', 'Waiter', 'Items Count', 'Gross (KSh)', 'Taxable Base (KSh)', '16% VAT', '2% Catering Levy', 'Payment Method', 'M-Pesa Ref', 'KRA Control Code'];
    const rows = paidOrders.map(o => [
      o.orderNumber,
      new Date(o.createdAt).toLocaleString(),
      o.table,
      o.waiterName,
      o.items.length,
      o.total,
      Math.round(o.total / 1.18),
      Math.round((o.total / 1.18) * 0.16),
      Math.round((o.total / 1.18) * 0.02),
      o.paymentMethod || 'mpesa',
      o.mpesaCode || '',
      o.kraControlCode || ''
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map(e => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `SimbaPOS_Sales_Report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      
      {/* Header & Controls */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-neutral-100 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-emerald-400" />
            Executive Sales Analytics & KRA Tax Ledger
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Real-time financial reconciliation for M-Pesa settlements, cash flow, and tax reporting.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Range selector */}
          <div className="flex items-center gap-1 p-1 bg-neutral-950 border border-neutral-800 rounded-lg text-xs">
            {(['today', 'week', 'month'] as const).map(range => (
              <button
                key={range}
                onClick={() => setTimeRange(range)}
                className={`px-3 py-1 rounded-md font-medium capitalize transition-colors ${
                  timeRange === range
                    ? 'bg-neutral-800 text-emerald-400 font-bold shadow-sm'
                    : 'text-neutral-400 hover:text-neutral-200'
                }`}
              >
                {range}
              </button>
            ))}
          </div>

          <button
            onClick={exportCsv}
            className="py-1.5 px-3 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-semibold rounded-md border border-neutral-700 flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            Export CSV
          </button>
        </div>
      </div>

      {/* 4 Metric KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1 */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Total Gross Revenue</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-neutral-100 tabular-nums">
            KSh {totalRevenue.toLocaleString()}
          </div>
          <p className="mt-1 text-[11px] text-emerald-400 flex items-center gap-1">
            <ArrowUpRight className="w-3 h-3" />
            +18.4% vs previous cycle
          </p>
        </div>

        {/* Metric 2 */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>M-Pesa Collections</span>
            <Smartphone className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-emerald-400 tabular-nums">
            KSh {mpesaTotal.toLocaleString()}
          </div>
          <p className="mt-1 text-[11px] text-neutral-400 font-mono">
            {mpesaPercent}% of all restaurant sales
          </p>
        </div>

        {/* Metric 3 */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Average Order Value</span>
            <TrendingUp className="w-4 h-4 text-sky-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-neutral-100 tabular-nums">
            KSh {aov.toLocaleString()}
          </div>
          <p className="mt-1 text-[11px] text-neutral-400 font-mono">
            {paidOrders.length} tables closed
          </p>
        </div>

        {/* Metric 4 */}
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>KRA Tax (16% VAT + 2%)</span>
            <ShieldCheck className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-2 text-2xl font-bold font-mono text-amber-400 tabular-nums">
            KSh {Math.round(totalVat + totalLevy).toLocaleString()}
          </div>
          <p className="mt-1 text-[11px] text-neutral-400 font-mono">
            PIN: {settings.kraPin}
          </p>
        </div>
      </div>

      {/* Middle Section: Payment Breakdown & Best Sellers */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left 6 Columns: Payment Channel Breakdown */}
        <div className="lg:col-span-6 bg-neutral-900 border border-neutral-800 rounded-lg p-5 space-y-4">
          <h3 className="font-bold text-sm text-neutral-100 flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-emerald-400" />
            Payment Channel Breakdown (Kenya)
          </h3>

          <div className="space-y-3 pt-2">
            {[
              { label: 'M-Pesa STK Push (Lipa na M-Pesa)', amount: mpesaStkTotal, color: 'bg-emerald-500' },
              { label: 'M-Pesa C2B / Till & Paybill Manual', amount: mpesaC2bTotal, color: 'bg-teal-400' },
              { label: 'Cash (Kenyan Shillings)', amount: cashTotal, color: 'bg-amber-400' },
              { label: 'Debit / Credit Card (Visa/Mastercard)', amount: cardTotal, color: 'bg-indigo-400' }
            ].map(ch => {
              const pct = totalRevenue > 0 ? Math.round((ch.amount / totalRevenue) * 100) : 0;
              return (
                <div key={ch.label} className="space-y-1 text-xs">
                  <div className="flex justify-between text-neutral-300">
                    <span>{ch.label}</span>
                    <span className="font-mono font-bold text-neutral-100 tabular-nums">
                      KSh {ch.amount.toLocaleString()} ({pct}%)
                    </span>
                  </div>
                  <div className="w-full h-2 bg-neutral-950 rounded-full overflow-hidden">
                    <div
                      className={`h-full ${ch.color} rounded-full transition-all duration-500`}
                      style={{ width: `${Math.max(4, pct)}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-3 bg-neutral-950 border border-neutral-800 rounded text-xs text-neutral-400 space-y-1">
            <div className="flex justify-between">
              <span>Safaricom M-Pesa Shortcode:</span>
              <span className="font-mono text-emerald-400">{settings.mpesaShortcode}</span>
            </div>
            <div className="flex justify-between">
              <span>Buy Goods Till Number:</span>
              <span className="font-mono text-emerald-400">{settings.mpesaTill}</span>
            </div>
          </div>
        </div>

        {/* Right 6 Columns: Top Dishes & Revenue Drivers */}
        <div className="lg:col-span-6 bg-neutral-900 border border-neutral-800 rounded-lg p-5 space-y-4">
          <h3 className="font-bold text-sm text-neutral-100">
            Top Selling Dishes & Revenue Leaders
          </h3>

          <div className="space-y-3 pt-2">
            {bestSellers.map((item, idx) => (
              <div key={item.name} className="flex items-center justify-between text-xs p-2.5 bg-neutral-950/60 rounded border border-neutral-800/80">
                <div className="flex items-center gap-2.5">
                  <span className="w-5 h-5 rounded bg-neutral-800 text-neutral-400 font-mono flex items-center justify-center font-bold text-[10px]">
                    0{idx + 1}
                  </span>
                  <div>
                    <div className="font-medium text-neutral-200">{item.name}</div>
                    <div className="text-[11px] text-neutral-400 font-mono">
                      {item.qty} portions sold
                    </div>
                  </div>
                </div>

                <span className="font-mono font-bold text-emerald-400 tabular-nums">
                  KSh {item.sales.toLocaleString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Hourly Dining Rush Profile */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-bold text-sm text-neutral-100">
              Restaurant Peak Hours & Sales Volume (Nairobi Time)
            </h3>
            <p className="text-xs text-neutral-400">
              Shows lunch rush (12-2 PM) and evening Nyama Choma rush (6-9 PM).
            </p>
          </div>
        </div>

        <div className="grid grid-cols-12 gap-2 pt-6 items-end h-44">
          {hourlyData.map(h => {
            const heightPct = Math.round((h.sales / maxHourSales) * 100);
            return (
              <div key={h.hour} className="flex flex-col items-center gap-1.5 h-full justify-end group">
                <div className="text-[10px] font-mono text-neutral-400 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                  KSh {Math.round(h.sales / 1000)}k
                </div>
                <div
                  className="w-full bg-emerald-500/20 group-hover:bg-emerald-500 rounded-t border-t border-emerald-400 transition-all duration-200"
                  style={{ height: `${heightPct}%` }}
                />
                <span className="text-[10px] font-mono text-neutral-400 whitespace-nowrap">
                  {h.label}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Settled Orders Ledger */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg overflow-hidden">
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
          <h3 className="font-bold text-sm text-neutral-100">
            Recent M-Pesa & Cash Transactions Ledger
          </h3>
          <span className="text-xs text-neutral-400 font-mono">
            {paidOrders.length} Completed
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-950 border-b border-neutral-800 text-neutral-400 font-mono">
              <tr>
                <th className="py-2.5 px-4 font-normal">Order #</th>
                <th className="py-2.5 px-4 font-normal">Time</th>
                <th className="py-2.5 px-4 font-normal">Table</th>
                <th className="py-2.5 px-4 font-normal">Waiter</th>
                <th className="py-2.5 px-4 font-normal">Method</th>
                <th className="py-2.5 px-4 font-normal">M-Pesa Ref</th>
                <th className="py-2.5 px-4 font-normal text-right">Taxable Base</th>
                <th className="py-2.5 px-4 font-normal text-right">16% VAT</th>
                <th className="py-2.5 px-4 font-normal text-right">Gross Total</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800">
              {paidOrders.map(o => (
                <tr key={o.id} className="hover:bg-neutral-800/40 transition-colors">
                  <td className="py-2.5 px-4 font-mono font-medium text-neutral-200">
                    #{o.orderNumber}
                  </td>
                  <td className="py-2.5 px-4 text-neutral-400 font-mono">
                    {new Date(o.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="py-2.5 px-4 text-neutral-300">{o.table}</td>
                  <td className="py-2.5 px-4 text-neutral-300">{o.waiterName}</td>
                  <td className="py-2.5 px-4 uppercase text-[11px] font-mono text-emerald-400">
                    {o.paymentMethod ? o.paymentMethod.replace('_', ' ') : 'M-PESA'}
                  </td>
                  <td className="py-2.5 px-4 font-mono text-neutral-300 font-semibold">
                    {o.mpesaCode || '-'}
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono tabular-nums text-neutral-400">
                    KSh {Math.round(o.total / 1.18).toLocaleString()}
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono tabular-nums text-neutral-400">
                    KSh {Math.round((o.total / 1.18) * 0.16).toLocaleString()}
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono font-bold tabular-nums text-emerald-400">
                    KSh {o.total.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
