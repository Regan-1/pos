import React from 'react';
import { StaffMember } from '../types';
import { UtensilsCrossed, Smartphone, Receipt, BarChart3, Users, ChefHat, UserCheck, Flame } from 'lucide-react';

interface HeaderProps {
  activeTab: 'pos' | 'kitchen' | 'receipts' | 'mpesa' | 'analytics' | 'staff';
  setActiveTab: (tab: 'pos' | 'kitchen' | 'receipts' | 'mpesa' | 'analytics' | 'staff') => void;
  currentStaff: StaffMember;
  onSwitchStaff: () => void;
  pendingOrderCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  currentStaff,
  onSwitchStaff,
  pendingOrderCount
}) => {
  return (
    <header className="border-b border-neutral-800 bg-neutral-900/95 sticky top-0 z-40 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single line, display face) */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
            <Flame className="w-5 h-5 text-emerald-400" />
          </div>
          <span className="text-base font-bold tracking-tight text-neutral-100 whitespace-nowrap">
            SimbaPOS Kenya
          </span>
          <span className="hidden lg:inline text-xs text-neutral-400 font-mono">
            Westlands · Nairobi
          </span>
        </div>

        {/* Zone 2: Navigation Links (Single-line controls) */}
        <nav className="hidden md:flex items-center gap-1 overflow-x-auto py-1">
          <button
            onClick={() => setActiveTab('pos')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'pos'
                ? 'bg-neutral-800 text-emerald-400 border border-neutral-700/80 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
            }`}
          >
            <UtensilsCrossed className="w-3.5 h-3.5" />
            POS Terminal
          </button>

          <button
            onClick={() => setActiveTab('kitchen')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 relative ${
              activeTab === 'kitchen'
                ? 'bg-neutral-800 text-emerald-400 border border-neutral-700/80 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
            }`}
          >
            <ChefHat className="w-3.5 h-3.5" />
            Kitchen Display
            {pendingOrderCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-amber-500 text-neutral-950 text-[10px] font-bold flex items-center justify-center ml-1">
                {pendingOrderCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('receipts')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'receipts'
                ? 'bg-neutral-800 text-emerald-400 border border-neutral-700/80 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
            }`}
          >
            <Receipt className="w-3.5 h-3.5" />
            Receipts & KRA
          </button>

          <button
            onClick={() => setActiveTab('mpesa')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'mpesa'
                ? 'bg-neutral-800 text-emerald-400 border border-neutral-700/80 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            M-Pesa & Python
          </button>

          <button
            onClick={() => setActiveTab('analytics')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'analytics'
                ? 'bg-neutral-800 text-emerald-400 border border-neutral-700/80 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            Sales Analytics
          </button>

          <button
            onClick={() => setActiveTab('staff')}
            className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'staff'
                ? 'bg-neutral-800 text-emerald-400 border border-neutral-700/80 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            Staff & Shifts
          </button>
        </nav>

        {/* Zone 3: Active Staff Button (Single primary action) */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onSwitchStaff}
            title="Click to switch staff user with PIN"
            className="flex items-center gap-2.5 px-3 py-1.5 text-xs rounded-md bg-neutral-800 border border-neutral-700 hover:border-neutral-600 transition-colors text-neutral-200 whitespace-nowrap shrink-0"
          >
            <div className="w-2 h-2 rounded-full bg-emerald-400" />
            <span className="font-semibold">{currentStaff.name}</span>
            <span className="text-neutral-500 capitalize">({currentStaff.role})</span>
            <UserCheck className="w-3.5 h-3.5 text-neutral-400 ml-1" />
          </button>
        </div>
      </div>
    </header>
  );
};
