import React, { useState } from 'react';
import { Order } from '../types';
import { Clock, ChefHat, CheckCircle, Utensils, Smartphone, Receipt, ArrowRight } from 'lucide-react';

interface KitchenOrdersProps {
  orders: Order[];
  onUpdateOrderStatus: (orderId: string, newStatus: Order['status']) => void;
  onOpenMpesaPay: (order: Order) => void;
  onViewReceipt: (order: Order) => void;
}

export const KitchenOrders: React.FC<KitchenOrdersProps> = ({
  orders,
  onUpdateOrderStatus,
  onOpenMpesaPay,
  onViewReceipt
}) => {
  const [filter, setFilter] = useState<'all' | 'active' | 'paid'>('active');

  const filteredOrders = orders.filter(o => {
    if (filter === 'active') return o.status !== 'paid';
    if (filter === 'paid') return o.status === 'paid';
    return true;
  });

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'pending': return 'text-amber-400 border-amber-500/30 bg-amber-500/10';
      case 'preparing': return 'text-sky-400 border-sky-500/30 bg-sky-500/10';
      case 'ready': return 'text-emerald-400 border-emerald-500/30 bg-emerald-500/10';
      case 'served': return 'text-purple-400 border-purple-500/30 bg-purple-500/10';
      case 'paid': return 'text-neutral-400 border-neutral-700 bg-neutral-800';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      
      {/* Top Bar with Filter Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-neutral-900 border border-neutral-800 p-4 rounded-lg">
        <div>
          <h2 className="text-base font-bold text-neutral-100 flex items-center gap-2">
            <ChefHat className="w-5 h-5 text-emerald-400" />
            Kitchen Display System (KDS) & Order Status
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Real-time floor tracking for chefs, waitstaff and cashiers.
          </p>
        </div>

        {/* Filter Segmented Buttons */}
        <div className="flex items-center gap-1 p-1 bg-neutral-950 border border-neutral-800 rounded-lg text-xs">
          <button
            onClick={() => setFilter('active')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              filter === 'active'
                ? 'bg-neutral-800 text-emerald-400 shadow-sm font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Active Tickets ({orders.filter(o => o.status !== 'paid').length})
          </button>
          <button
            onClick={() => setFilter('paid')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              filter === 'paid'
                ? 'bg-neutral-800 text-emerald-400 shadow-sm font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Settled / Paid ({orders.filter(o => o.status === 'paid').length})
          </button>
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              filter === 'all'
                ? 'bg-neutral-800 text-emerald-400 shadow-sm font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            All Orders ({orders.length})
          </button>
        </div>
      </div>

      {/* Orders Grid */}
      {filteredOrders.length === 0 ? (
        <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-12 text-center text-neutral-500 space-y-2">
          <Utensils className="w-8 h-8 text-neutral-600 mx-auto" />
          <p className="text-sm font-medium text-neutral-300">No orders matching this view</p>
          <p className="text-xs text-neutral-500">Orders placed on the POS terminal appear here instantly.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredOrders.map(order => {
            const isPaid = order.status === 'paid';
            const timeAgo = new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

            return (
              <div
                key={order.id}
                className={`bg-neutral-900 border rounded-lg overflow-hidden flex flex-col justify-between transition-all ${
                  order.status === 'ready'
                    ? 'border-emerald-500/50 shadow-lg shadow-emerald-950/20'
                    : 'border-neutral-800'
                }`}
              >
                {/* Header */}
                <div className="p-4 bg-neutral-950/50 border-b border-neutral-800 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-neutral-100">{order.table}</span>
                      <span className="text-neutral-500 text-xs">·</span>
                      <span className="text-xs font-mono text-neutral-400">#{order.orderNumber}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-neutral-400 mt-0.5">
                      <Clock className="w-3 h-3 text-neutral-500" />
                      <span>{timeAgo}</span>
                      <span>·</span>
                      <span>Waiter: {order.waiterName}</span>
                    </div>
                  </div>

                  <span className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded border capitalize ${getStatusColor(order.status)}`}>
                    {order.status}
                  </span>
                </div>

                {/* Items List */}
                <div className="p-4 space-y-2 flex-1">
                  {order.items.map((item, idx) => (
                    <div key={idx} className="flex items-start justify-between text-xs">
                      <div className="pr-2">
                        <span className="font-semibold text-neutral-200">{item.quantity}x</span>{' '}
                        <span className="text-neutral-300">{item.name}</span>
                        {item.notes && (
                          <p className="text-[11px] text-amber-400/90 italic mt-0.5">
                            Note: {item.notes}
                          </p>
                        )}
                      </div>
                      <span className="font-mono text-neutral-400 tabular-nums shrink-0">
                        KSh {(item.price * item.quantity).toLocaleString()}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Total & Action Footer */}
                <div className="p-4 bg-neutral-950/80 border-t border-neutral-800 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-neutral-400">Total Amount:</span>
                    <span className="font-bold font-mono text-neutral-100 text-sm tabular-nums">
                      KSh {order.total.toLocaleString()}
                    </span>
                  </div>

                  {order.mpesaCode && (
                    <div className="text-[11px] text-emerald-400 font-mono flex items-center justify-between bg-emerald-950/20 px-2 py-1 rounded border border-emerald-900/30">
                      <span>M-Pesa Ref:</span>
                      <span className="font-bold">{order.mpesaCode}</span>
                    </div>
                  )}

                  {/* Status Progression Controls */}
                  <div className="flex gap-2">
                    {order.status === 'pending' && (
                      <button
                        onClick={() => onUpdateOrderStatus(order.id, 'preparing')}
                        className="flex-1 py-1.5 text-xs font-medium rounded bg-sky-950 text-sky-300 border border-sky-800 hover:bg-sky-900 transition-colors flex items-center justify-center gap-1"
                      >
                        <ChefHat className="w-3.5 h-3.5" />
                        Start Cooking
                      </button>
                    )}

                    {order.status === 'preparing' && (
                      <button
                        onClick={() => onUpdateOrderStatus(order.id, 'ready')}
                        className="flex-1 py-1.5 text-xs font-bold rounded bg-emerald-600 text-neutral-950 hover:bg-emerald-500 transition-colors flex items-center justify-center gap-1"
                      >
                        <CheckCircle className="w-3.5 h-3.5" />
                        Mark Ready to Serve
                      </button>
                    )}

                    {order.status === 'ready' && (
                      <button
                        onClick={() => onUpdateOrderStatus(order.id, 'served')}
                        className="flex-1 py-1.5 text-xs font-medium rounded bg-purple-950 text-purple-300 border border-purple-800 hover:bg-purple-900 transition-colors flex items-center justify-center gap-1"
                      >
                        <Utensils className="w-3.5 h-3.5" />
                        Mark Served to Table
                      </button>
                    )}

                    {!isPaid ? (
                      <button
                        onClick={() => onOpenMpesaPay(order)}
                        className="flex-1 py-1.5 text-xs font-bold rounded bg-emerald-500 text-neutral-950 hover:bg-emerald-400 transition-colors flex items-center justify-center gap-1 shadow"
                      >
                        <Smartphone className="w-3.5 h-3.5" />
                        Pay M-Pesa
                      </button>
                    ) : (
                      <button
                        onClick={() => onViewReceipt(order)}
                        className="flex-1 py-1.5 text-xs font-medium rounded bg-neutral-800 text-neutral-200 hover:bg-neutral-700 transition-colors border border-neutral-700 flex items-center justify-center gap-1"
                      >
                        <Receipt className="w-3.5 h-3.5 text-emerald-400" />
                        View Receipt
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
