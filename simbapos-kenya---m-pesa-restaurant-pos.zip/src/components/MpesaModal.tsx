import React, { useState, useEffect } from 'react';
import { Order } from '../types';
import { Smartphone, CheckCircle2, AlertCircle, Loader2, ArrowRight, ShieldCheck, X, RefreshCw, KeyRound } from 'lucide-react';
import { posAudio } from '../utils/audio';

interface MpesaModalProps {
  order: Partial<Order>;
  isOpen: boolean;
  onClose: () => void;
  onPaymentSuccess: (paidOrder: Order) => void;
}

export const MpesaModal: React.FC<MpesaModalProps> = ({
  order,
  isOpen,
  onClose,
  onPaymentSuccess
}) => {
  const [activeMode, setActiveMode] = useState<'stk' | 'manual'>('stk');
  const [phoneNumber, setPhoneNumber] = useState('0712345678');
  const [manualCode, setManualCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState('');
  const [stkStatus, setStkStatus] = useState<'idle' | 'prompt_sent' | 'customer_pin' | 'verifying' | 'confirmed' | 'failed'>('idle');
  const [checkoutId, setCheckoutId] = useState('');
  const [receiptCode, setReceiptCode] = useState('');
  const [simulatedPin, setSimulatedPin] = useState('2468');
  const [countdown, setCountdown] = useState(30);

  useEffect(() => {
    if (isOpen) {
      setStkStatus('idle');
      setIsLoading(false);
      setStatusMessage('');
      setManualCode('');
      setCountdown(30);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const totalAmount = order.total || 0;

  // Format Kenyan phone number
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/[^0-9]/g, '');
    if (val.length > 12) val = val.slice(0, 12);
    setPhoneNumber(val);
  };

  // Trigger STK Push via Python backend
  const handleInitiateStk = async () => {
    if (!phoneNumber || phoneNumber.length < 9) {
      setStatusMessage('Please enter a valid Kenyan phone number (e.g. 0712345678 or 254712345678)');
      return;
    }

    setIsLoading(true);
    setStkStatus('prompt_sent');
    setStatusMessage('Connecting to Safaricom Daraja API via Python service...');

    try {
      const response = await fetch('/api/mpesa/stkpush', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: phoneNumber,
          amount: totalAmount,
          account: `${order.table || 'Simba POS'}`,
          orderId: order.id
        })
      });

      const data = await response.json();

      if (data.status === 'success') {
        setCheckoutId(data.checkoutId || data.CheckoutRequestID);
        setReceiptCode(data.simulated_receipt || `SK${Math.floor(10000000 + Math.random() * 90000000)}`);
        setStkStatus('customer_pin');
        setStatusMessage('STK Push Prompt sent to customer phone. Awaiting M-Pesa PIN...');
      } else {
        setStkStatus('failed');
        setStatusMessage(data.message || 'Safaricom Daraja request failed.');
      }
    } catch (err: any) {
      setStkStatus('failed');
      setStatusMessage('Network connection error: ' + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Complete Payment after simulated/real customer PIN entry
  const handleConfirmPin = async () => {
    setIsLoading(true);
    setStkStatus('verifying');
    setStatusMessage('Verifying M-Pesa transaction with Safaricom ledger...');

    try {
      const res = await fetch(`/api/mpesa/query?checkout_id=${checkoutId}&order_id=${order.id}`);
      const data = await res.json();

      const finalCode = data.MpesaReceiptNumber || receiptCode || `SK${Math.floor(10000000 + Math.random() * 90000000)}`;

      posAudio.playMpesaChime();
      setStkStatus('confirmed');
      setStatusMessage(`Payment Verified! Safaricom Receipt: ${finalCode}`);

      const paidOrder: Order = {
        ...(order as Order),
        status: 'paid',
        paymentMethod: 'mpesa_stk',
        mpesaCode: finalCode,
        customerPhone: phoneNumber,
        paidAt: new Date().toISOString(),
        kraControlCode: `KRA-ETR-${order.orderNumber?.replace('ORD-', '') || '8492'}${Math.floor(10 + Math.random() * 90)}`
      };

      setTimeout(() => {
        onPaymentSuccess(paidOrder);
      }, 1200);

    } catch (err: any) {
      setStkStatus('failed');
      setStatusMessage('Verification error: ' + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Verify Manual C2B / Till Code
  const handleManualCodeVerify = async () => {
    if (!manualCode || manualCode.trim().length !== 10) {
      setStatusMessage('Invalid format. Safaricom M-Pesa codes must be 10 characters (e.g. SK92KL8491)');
      return;
    }

    setIsLoading(true);
    setStatusMessage('Verifying code with Safaricom Daraja C2B ledger in Python...');

    try {
      const response = await fetch('/api/mpesa/c2b-verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: manualCode.trim().toUpperCase(),
          amount: totalAmount,
          orderId: order.id
        })
      });

      const data = await response.json();

      if (data.valid) {
        posAudio.playMpesaChime();
        setStkStatus('confirmed');
        setStatusMessage(`Code ${manualCode.toUpperCase()} verified!`);

        const paidOrder: Order = {
          ...(order as Order),
          status: 'paid',
          paymentMethod: 'mpesa_c2b',
          mpesaCode: manualCode.trim().toUpperCase(),
          customerPhone: phoneNumber || '2547XXXXXXXX',
          paidAt: new Date().toISOString(),
          kraControlCode: `KRA-ETR-${order.orderNumber?.replace('ORD-', '') || '8492'}${Math.floor(10 + Math.random() * 90)}`
        };

        setTimeout(() => {
          onPaymentSuccess(paidOrder);
        }, 1200);
      } else {
        setStatusMessage(data.error || 'Invalid or unverified M-Pesa code.');
      }
    } catch (err: any) {
      setStatusMessage('Verification error: ' + err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl max-w-lg w-full overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header with Safaricom Green Accent */}
        <div className="p-4 bg-neutral-950 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold">
              M
            </div>
            <div>
              <h3 className="font-bold text-sm text-neutral-100 flex items-center gap-2">
                Safaricom Lipa Na M-Pesa
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                  Python Daraja 2.0
                </span>
              </h3>
              <p className="text-xs text-neutral-400">
                {order.table} · {order.orderNumber}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-neutral-400 hover:text-neutral-200 transition-colors p-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Amount Banner */}
        <div className="px-6 py-4 bg-emerald-950/20 border-b border-emerald-900/30 flex items-center justify-between">
          <span className="text-xs text-emerald-300 font-medium">Total Amount to Pay:</span>
          <span className="text-xl font-bold font-mono text-emerald-400 tabular-nums">
            KSh {totalAmount.toLocaleString()}
          </span>
        </div>

        {/* Mode Selector Tabs */}
        <div className="p-4 border-b border-neutral-800 flex items-center gap-2">
          <button
            onClick={() => { setActiveMode('stk'); setStkStatus('idle'); setStatusMessage(''); }}
            className={`flex-1 py-2 px-3 text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${
              activeMode === 'stk'
                ? 'bg-neutral-800 text-emerald-400 border border-neutral-700 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            STK Push (Instant Prompt)
          </button>

          <button
            onClick={() => { setActiveMode('manual'); setStkStatus('idle'); setStatusMessage(''); }}
            className={`flex-1 py-2 px-3 text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-2 ${
              activeMode === 'manual'
                ? 'bg-neutral-800 text-emerald-400 border border-neutral-700 shadow-sm'
                : 'text-neutral-400 hover:text-neutral-200 hover:bg-neutral-800/50'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            Buy Goods Till / Code
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5">
          {activeMode === 'stk' ? (
            <div className="space-y-4">
              {stkStatus === 'idle' && (
                <>
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-neutral-300 block">
                      Customer Phone Number (Safaricom)
                    </label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-mono text-neutral-400">
                        🇰🇪 +254
                      </span>
                      <input
                        type="text"
                        value={phoneNumber}
                        onChange={handlePhoneChange}
                        placeholder="712345678 or 0712345678"
                        className="w-full pl-20 pr-3 py-2.5 bg-neutral-950 border border-neutral-800 rounded-md font-mono text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                    <p className="text-[11px] text-neutral-400">
                      Safaricom will display a popup PIN prompt directly on customer&apos;s phone.
                    </p>
                  </div>

                  <button
                    onClick={handleInitiateStk}
                    disabled={isLoading}
                    className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-neutral-950 font-bold text-xs rounded-md flex items-center justify-center gap-2 transition-colors shadow-lg shadow-emerald-950/40"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Triggering Daraja STK Push...
                      </>
                    ) : (
                      <>
                        <Smartphone className="w-4 h-4" />
                        Send M-Pesa Prompt (KSh {totalAmount.toLocaleString()})
                      </>
                    )}
                  </button>
                </>
              )}

              {/* Waiting for PIN / Phone Simulation */}
              {stkStatus === 'customer_pin' && (
                <div className="space-y-4">
                  {/* Visual Customer Mobile Phone Simulation */}
                  <div className="p-4 bg-neutral-950 border border-emerald-500/40 rounded-lg relative overflow-hidden shadow-inner">
                    <div className="flex items-center justify-between pb-2 mb-3 border-b border-neutral-800 text-[11px] text-neutral-400 font-mono">
                      <span>SIM Toolkit · M-Pesa</span>
                      <span className="text-emerald-400 animate-pulse font-semibold">Active Session</span>
                    </div>

                    <div className="text-center space-y-2 py-2">
                      <p className="text-xs text-neutral-200">
                        Do you want to pay <span className="font-bold text-emerald-400">KSh {totalAmount.toLocaleString()}</span> to <span className="font-semibold text-neutral-100">SIMBA GRILL (Till 849201)</span>?
                      </p>
                      
                      <div className="py-2">
                        <label className="text-[11px] text-neutral-400 block mb-1">Enter M-Pesa PIN:</label>
                        <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-neutral-900 border border-neutral-700 rounded font-mono text-sm tracking-widest text-emerald-400">
                          ••••
                        </div>
                      </div>

                      <p className="text-[10px] text-neutral-400">
                        Pressing send simulates customer typing their secret PIN on their mobile phone.
                      </p>
                    </div>

                    <div className="flex gap-2 pt-3 border-t border-neutral-800 mt-2">
                      <button
                        onClick={() => { setStkStatus('idle'); setStatusMessage('STK Push cancelled.'); }}
                        className="flex-1 py-1.5 text-xs text-neutral-400 hover:text-neutral-200 bg-neutral-900 rounded"
                      >
                        Cancel Prompt
                      </button>
                      <button
                        onClick={handleConfirmPin}
                        disabled={isLoading}
                        className="flex-1 py-1.5 text-xs font-bold text-neutral-950 bg-emerald-500 hover:bg-emerald-400 rounded flex items-center justify-center gap-1.5 shadow"
                      >
                        {isLoading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ShieldCheck className="w-3.5 h-3.5" />}
                        Approve & Confirm PIN
                      </button>
                    </div>
                  </div>

                  <div className="text-center">
                    <p className="text-xs text-neutral-400">
                      Checkout Request ID: <span className="font-mono text-neutral-300">{checkoutId}</span>
                    </p>
                  </div>
                </div>
              )}

              {stkStatus === 'verifying' && (
                <div className="py-8 text-center space-y-3">
                  <Loader2 className="w-8 h-8 animate-spin text-emerald-400 mx-auto" />
                  <p className="text-xs text-neutral-300">{statusMessage}</p>
                </div>
              )}

              {stkStatus === 'confirmed' && (
                <div className="py-6 text-center space-y-2">
                  <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
                  <h4 className="font-bold text-sm text-neutral-100">M-Pesa Payment Received!</h4>
                  <p className="text-xs text-emerald-400 font-mono font-semibold">
                    Receipt Code: {receiptCode}
                  </p>
                  <p className="text-[11px] text-neutral-400">Opening KRA Digital Receipt...</p>
                </div>
              )}

              {stkStatus === 'failed' && (
                <div className="p-3 bg-rose-950/30 border border-rose-800/50 rounded-lg text-xs text-rose-300 space-y-2">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    <span>{statusMessage}</span>
                  </div>
                  <button
                    onClick={() => setStkStatus('idle')}
                    className="text-xs underline text-rose-200 hover:text-white"
                  >
                    Try Again
                  </button>
                </div>
              )}
            </div>
          ) : (
            /* Mode 2: Manual Buy Goods / Till / Paybill Code Entry */
            <div className="space-y-4">
              <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-lg text-xs space-y-2">
                <div className="flex items-center justify-between text-neutral-300">
                  <span>Simba Grill Buy Goods (Till):</span>
                  <span className="font-mono font-bold text-emerald-400 text-sm">849201</span>
                </div>
                <div className="flex items-center justify-between text-neutral-300">
                  <span>Paybill Number:</span>
                  <span className="font-mono font-bold text-emerald-400 text-sm">522522</span>
                </div>
                <div className="flex items-center justify-between text-neutral-300">
                  <span>Account Number:</span>
                  <span className="font-mono font-bold text-neutral-100">{order.table || 'TABLE 4'}</span>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-medium text-neutral-300 block">
                  Enter 10-Digit Safaricom SMS Transaction Code:
                </label>
                <input
                  type="text"
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value.toUpperCase())}
                  placeholder="e.g. SK92KL8491 or QA84PJ9021"
                  maxLength={10}
                  className="w-full px-3 py-2.5 bg-neutral-950 border border-neutral-800 rounded-md font-mono text-sm uppercase text-emerald-400 placeholder-neutral-600 focus:outline-none focus:border-emerald-500"
                />
                <p className="text-[11px] text-neutral-400">
                  Found in customer&apos;s Safaricom SMS (e.g. &quot;Confirmed. Ksh... sent to SIMBA GRILL&quot;).
                </p>
              </div>

              {statusMessage && (
                <p className="text-xs text-amber-400">{statusMessage}</p>
              )}

              <button
                onClick={handleManualCodeVerify}
                disabled={isLoading || manualCode.length < 8}
                className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 text-neutral-950 font-bold text-xs rounded-md flex items-center justify-center gap-2 transition-colors"
              >
                {isLoading ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <CheckCircle2 className="w-4 h-4" />
                )}
                Verify & Complete Order
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
