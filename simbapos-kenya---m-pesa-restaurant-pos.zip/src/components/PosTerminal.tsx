import React, { useState } from 'react';
import { MenuItem, OrderItem, StaffMember, Order } from '../types';
import { Search, Plus, Minus, Trash2, Smartphone, DollarSign, Clock, Users, Send, CreditCard, Sparkles, AlertCircle } from 'lucide-react';
import { posAudio } from '../utils/audio';

interface PosTerminalProps {
  menu: MenuItem[];
  currentStaff: StaffMember;
  onOpenMpesaPay: (order: Partial<Order>) => void;
  onSendToKitchen: (order: Partial<Order>) => void;
  onDirectCheckout: (order: Partial<Order>, method: 'cash' | 'card') => void;
}

const tableOptions = [
  'Table 1', 'Table 2', 'Table 3', 'Table 4', 'Table 5', 'Table 6',
  'VIP Lounge 1', 'VIP Lounge 2', 'VIP Lounge 3',
  'Terrace 1', 'Terrace 2', 'Terrace 3', 'Terrace 4',
  'Takeaway / Delivery'
];

export const PosTerminal: React.FC<PosTerminalProps> = ({
  menu,
  currentStaff,
  onOpenMpesaPay,
  onSendToKitchen,
  onDirectCheckout
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTable, setSelectedTable] = useState('Table 4');
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [guestCount, setGuestCount] = useState(1);
  const [itemNoteModal, setItemNoteModal] = useState<{ itemId: string; currentNote: string } | null>(null);

  // Filtered menu
  const filteredMenu = menu.filter(item => {
    const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (item.swahiliName && item.swahiliName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      item.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const addToCart = (item: MenuItem) => {
    posAudio.playClick();
    setCart(prev => {
      const existing = prev.find(i => i.id === item.id);
      if (existing) {
        return prev.map(i => i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { id: item.id, name: item.name, price: item.price, quantity: 1 }];
    });
  };

  const updateQuantity = (itemId: string, delta: number) => {
    posAudio.playClick();
    setCart(prev => {
      return prev.map(item => {
        if (item.id === itemId) {
          const newQty = item.quantity + delta;
          return newQty > 0 ? { ...item, quantity: newQty } : null;
        }
        return item;
      }).filter(Boolean) as OrderItem[];
    });
  };

  const removeItem = (itemId: string) => {
    posAudio.playClick();
    setCart(prev => prev.filter(i => i.id !== itemId));
  };

  const updateNote = (itemId: string, note: string) => {
    setCart(prev => prev.map(i => i.id === itemId ? { ...i, notes: note } : i));
    setItemNoteModal(null);
  };

  // Tax and totals calculations
  const grossTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const netAmount = grossTotal / 1.18; // 16% VAT + 2% Catering Levy inclusive
  const vat16 = netAmount * 0.16;
  const cateringLevy2 = netAmount * 0.02;

  const prepareCurrentOrder = (status: Order['status'] = 'pending'): Partial<Order> => {
    return {
      id: `ord-${Date.now().toString().slice(-6)}`,
      orderNumber: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
      table: selectedTable,
      waiterId: currentStaff.id,
      waiterName: currentStaff.name,
      status,
      items: [...cart],
      subtotal: Math.round(netAmount * 100) / 100,
      vat16: Math.round(vat16 * 100) / 100,
      cateringLevy2: Math.round(cateringLevy2 * 100) / 100,
      total: grossTotal,
      createdAt: new Date().toISOString()
    };
  };

  const handleMpesaPayClick = () => {
    if (cart.length === 0) return;
    onOpenMpesaPay(prepareCurrentOrder('pending'));
  };

  const handleKitchenClick = () => {
    if (cart.length === 0) return;
    onSendToKitchen(prepareCurrentOrder('preparing'));
    setCart([]);
  };

  const handleDirectCash = () => {
    if (cart.length === 0) return;
    onDirectCheckout(prepareCurrentOrder('paid'), 'cash');
    setCart([]);
  };

  const handleDirectCard = () => {
    if (cart.length === 0) return;
    onDirectCheckout(prepareCurrentOrder('paid'), 'card');
    setCart([]);
  };

  // Image mapper for authentic visuals
  const getItemImage = (id: string) => {
    if (id === 'm1' || id === 'm2' || id === 'm3') return '/src/assets/images/nyama_choma_grill_1794129040939.jpg';
    if (id === 'm7' || id === 'm8') return '/src/assets/images/tilapia_wet_fry_1794129041951.jpg';
    if (id === 'm9' || id === 'm10') return '/src/assets/images/swahili_beef_biryani_1794129042020.jpg';
    return null;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left 8 Columns: Category filters, search, and menu catalog */}
        <div className="lg:col-span-7 xl:col-span-8 space-y-4">
          
          {/* Top Controls: Search and Table Selector */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-4 flex flex-col sm:flex-row items-center gap-4 justify-between">
            {/* Search Input */}
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search dish, Swahili name, or drink..."
                className="w-full pl-9 pr-3 py-2 bg-neutral-950 border border-neutral-800 rounded-md text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500/50"
              />
            </div>

            {/* Table Selector */}
            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-xs text-neutral-400 whitespace-nowrap">Table:</span>
              <select
                value={selectedTable}
                onChange={(e) => setSelectedTable(e.target.value)}
                className="bg-neutral-950 border border-neutral-800 rounded-md px-3 py-2 text-xs font-semibold text-emerald-400 focus:outline-none focus:border-emerald-500/50"
              >
                {tableOptions.map(t => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
            {[
              { id: 'all', label: 'All Dishes' },
              { id: 'choma', label: '🔥 Choma & Grills' },
              { id: 'swahili', label: '🥘 Coastal & Swahili' },
              { id: 'traditional', label: '🍲 Traditional Mains' },
              { id: 'bites', label: '🥟 Fast Bites & Sides' },
              { id: 'drinks', label: '🍹 Drinks & Dawa' }
            ].map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-md transition-colors whitespace-nowrap font-medium shrink-0 ${
                  selectedCategory === cat.id
                    ? 'bg-neutral-800 text-emerald-400 border border-neutral-700/80 shadow-sm'
                    : 'bg-neutral-900/50 text-neutral-400 border border-neutral-800/80 hover:text-neutral-200 hover:bg-neutral-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Menu Items Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredMenu.map(item => {
              const imageSrc = getItemImage(item.id);
              const inCartCount = cart.find(c => c.id === item.id)?.quantity || 0;

              return (
                <div
                  key={item.id}
                  onClick={() => addToCart(item)}
                  className="group bg-neutral-900 border border-neutral-800 hover:border-neutral-700 rounded-lg overflow-hidden flex flex-col justify-between transition-all duration-150 cursor-pointer text-left hover:bg-neutral-900/80"
                >
                  {imageSrc ? (
                    <div className="h-32 w-full overflow-hidden relative bg-neutral-950">
                      <img
                        src={imageSrc}
                        alt={item.name}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/90 via-neutral-950/20 to-transparent" />
                      <div className="absolute bottom-2 left-2 right-2 flex justify-between items-end">
                        <span className="text-[11px] text-neutral-300 font-mono flex items-center gap-1 bg-black/60 px-1.5 py-0.5 rounded backdrop-blur-sm">
                          <Clock className="w-3 h-3 text-neutral-400" />
                          {item.preparationTime}
                        </span>
                        <span className="font-mono text-xs font-bold text-emerald-400 bg-neutral-900/90 px-2 py-0.5 rounded border border-emerald-500/30">
                          KSh {item.price.toLocaleString()}
                        </span>
                      </div>
                    </div>
                  ) : null}

                  <div className="p-3.5 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="font-semibold text-sm text-neutral-100 group-hover:text-emerald-400 transition-colors">
                          {item.name}
                        </h4>
                        {!imageSrc && (
                          <span className="font-mono text-xs font-bold text-emerald-400 shrink-0">
                            KSh {item.price.toLocaleString()}
                          </span>
                        )}
                      </div>

                      {item.swahiliName && (
                        <p className="text-[11px] text-neutral-400 italic mt-0.5">
                          {item.swahiliName}
                        </p>
                      )}

                      <p className="text-xs text-neutral-400 line-clamp-2 mt-1 leading-relaxed">
                        {item.description}
                      </p>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-neutral-800/60 flex items-center justify-between text-xs">
                      {!imageSrc && (
                        <span className="text-[11px] text-neutral-400 font-mono flex items-center gap-1">
                          <Clock className="w-3 h-3 text-neutral-500" />
                          {item.preparationTime}
                        </span>
                      )}

                      <div className="ml-auto flex items-center gap-2">
                        {inCartCount > 0 && (
                          <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                            {inCartCount} in ticket
                          </span>
                        )}
                        <button
                          type="button"
                          className="px-2.5 py-1 rounded bg-neutral-800 hover:bg-emerald-500 hover:text-neutral-950 font-medium text-xs text-neutral-200 transition-colors flex items-center gap-1"
                        >
                          <Plus className="w-3 h-3" />
                          Add
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right 5 Columns: Active Order Ticket & Checkout */}
        <div className="lg:col-span-5 xl:col-span-4 bg-neutral-900 border border-neutral-800 rounded-lg flex flex-col sticky top-20 shadow-xl">
          
          {/* Ticket Header */}
          <div className="p-4 border-b border-neutral-800 flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-neutral-100">{selectedTable}</span>
                <span className="text-neutral-500 text-xs">·</span>
                <span className="text-xs text-neutral-400 font-mono">Dine-In</span>
              </div>
              <p className="text-xs text-neutral-400 mt-0.5">
                Waiter: <span className="text-neutral-300 font-medium">{currentStaff.name}</span>
              </p>
            </div>

            {cart.length > 0 && (
              <button
                onClick={() => setCart([])}
                className="text-xs text-neutral-400 hover:text-rose-400 flex items-center gap-1 transition-colors"
                title="Clear Ticket"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Clear
              </button>
            )}
          </div>

          {/* Ticket Items List */}
          <div className="p-4 space-y-3 max-h-[380px] overflow-y-auto divide-y divide-neutral-800/60">
            {cart.length === 0 ? (
              <div className="py-12 text-center text-neutral-500 space-y-2">
                <p className="text-xs">Ticket is empty</p>
                <p className="text-[11px] text-neutral-400">Click dishes from the menu to build table order</p>
              </div>
            ) : (
              cart.map(item => (
                <div key={item.id} className="pt-3 first:pt-0 flex items-start justify-between gap-3 text-xs">
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-neutral-200 truncate">{item.name}</div>
                    <div className="text-neutral-400 font-mono text-[11px] mt-0.5">
                      KSh {item.price.toLocaleString()} each
                    </div>
                    {item.notes ? (
                      <p className="text-[11px] text-amber-400/90 italic mt-0.5">
                        Note: {item.notes}
                      </p>
                    ) : (
                      <button
                        onClick={() => setItemNoteModal({ itemId: item.id, currentNote: item.notes || '' })}
                        className="text-[10px] text-neutral-400 hover:text-neutral-300 mt-0.5 underline block"
                      >
                        + Add chef note
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <div className="flex items-center bg-neutral-950 border border-neutral-800 rounded">
                      <button
                        onClick={() => updateQuantity(item.id, -1)}
                        className="p-1 text-neutral-400 hover:text-neutral-100"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-6 text-center font-mono font-semibold text-neutral-200 text-xs">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateQuantity(item.id, 1)}
                        className="p-1 text-neutral-400 hover:text-neutral-100"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <span className="w-16 text-right font-mono font-semibold text-neutral-100 tabular-nums">
                      KSh {(item.price * item.quantity).toLocaleString()}
                    </span>

                    <button
                      onClick={() => removeItem(item.id)}
                      className="text-neutral-400 hover:text-rose-400 transition-colors ml-1"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Split Bill Calculator & Tax Breakdown */}
          {cart.length > 0 && (
            <div className="p-4 bg-neutral-950/60 border-t border-neutral-800 space-y-2 text-xs">
              <div className="flex items-center justify-between text-neutral-400">
                <span>Taxable Base (Excl. Tax):</span>
                <span className="font-mono tabular-nums">KSh {Math.round(netAmount).toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between text-neutral-400">
                <span>16% VAT (Kenya):</span>
                <span className="font-mono tabular-nums">KSh {Math.round(vat16).toLocaleString()}</span>
              </div>
              <div className="flex items-center justify-between text-neutral-400">
                <span>2% Catering Levy:</span>
                <span className="font-mono tabular-nums">KSh {Math.round(cateringLevy2).toLocaleString()}</span>
              </div>

              {/* Split bill controls */}
              <div className="pt-2 border-t border-neutral-800/60 flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-neutral-400">
                  <Users className="w-3 h-3" />
                  <span>Split bill ({guestCount} pax):</span>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setGuestCount(Math.max(1, guestCount - 1))}
                    className="w-5 h-5 bg-neutral-800 rounded flex items-center justify-center text-neutral-300 text-xs"
                  >
                    -
                  </button>
                  <span className="w-4 text-center font-mono font-bold text-neutral-200">{guestCount}</span>
                  <button
                    onClick={() => setGuestCount(guestCount + 1)}
                    className="w-5 h-5 bg-neutral-800 rounded flex items-center justify-center text-neutral-300 text-xs"
                  >
                    +
                  </button>
                </div>
              </div>

              {guestCount > 1 && (
                <div className="flex items-center justify-between text-emerald-400/90 font-mono text-[11px]">
                  <span>Each person pays:</span>
                  <span className="font-bold">KSh {Math.round(grossTotal / guestCount).toLocaleString()}</span>
                </div>
              )}

              {/* Total Payable */}
              <div className="pt-2 border-t border-neutral-800 flex items-center justify-between">
                <span className="text-sm font-bold text-neutral-100">Total Payable:</span>
                <span className="text-base font-bold text-emerald-400 font-mono tabular-nums">
                  KSh {grossTotal.toLocaleString()}
                </span>
              </div>
            </div>
          )}

          {/* Checkout & Payment Action Buttons */}
          <div className="p-4 border-t border-neutral-800 space-y-2">
            {/* Primary Action: Lipa na M-Pesa STK Push */}
            <button
              disabled={cart.length === 0}
              onClick={handleMpesaPayClick}
              className="w-full py-2.5 px-4 rounded-md bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:pointer-events-none text-neutral-950 font-bold text-xs flex items-center justify-center gap-2 transition-colors shadow-lg shadow-emerald-950/40"
            >
              <Smartphone className="w-4 h-4 text-neutral-950" />
              Lipa Na M-Pesa (STK Push)
            </button>

            {/* Secondary Actions Row */}
            <div className="grid grid-cols-2 gap-2">
              <button
                disabled={cart.length === 0}
                onClick={handleKitchenClick}
                className="py-2 px-3 rounded-md bg-neutral-800 hover:bg-neutral-700 disabled:opacity-40 disabled:pointer-events-none text-neutral-200 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors border border-neutral-700/60"
              >
                <Send className="w-3.5 h-3.5 text-amber-400" />
                Send to Kitchen
              </button>

              <button
                disabled={cart.length === 0}
                onClick={handleDirectCash}
                className="py-2 px-3 rounded-md bg-neutral-800 hover:bg-neutral-700 disabled:opacity-40 disabled:pointer-events-none text-neutral-200 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors border border-neutral-700/60"
              >
                <DollarSign className="w-3.5 h-3.5 text-neutral-300" />
                Cash Checkout
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Item Note Modal */}
      {itemNoteModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-5 max-w-sm w-full space-y-4">
            <h4 className="font-semibold text-sm text-neutral-100">Special Cooking Request</h4>
            <input
              type="text"
              autoFocus
              defaultValue={itemNoteModal.currentNote}
              placeholder="e.g., Ugali saucer moto, bila pilipili, well-done choma"
              id="dish-note-input"
              className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded text-xs text-neutral-100 focus:outline-none focus:border-emerald-500"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  updateNote(itemNoteModal.itemId, (e.target as HTMLInputElement).value);
                }
              }}
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setItemNoteModal(null)}
                className="px-3 py-1.5 text-xs text-neutral-400 hover:text-neutral-200"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const input = document.getElementById('dish-note-input') as HTMLInputElement;
                  updateNote(itemNoteModal.itemId, input?.value || '');
                }}
                className="px-3 py-1.5 text-xs bg-emerald-500 text-neutral-950 font-bold rounded"
              >
                Save Note
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
