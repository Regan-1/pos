import React, { useState } from 'react';
import { Order, RestaurantSettings } from '../types';
import { Printer, Share2, Download, Copy, Check, X, Phone, MessageSquare } from 'lucide-react';
import { posAudio } from '../utils/audio';

interface ReceiptModalProps {
  order: Order | null;
  settings: RestaurantSettings;
  isOpen: boolean;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  order,
  settings,
  isOpen,
  onClose
}) => {
  const [copied, setCopied] = useState(false);
  const [receiptWidth, setReceiptWidth] = useState<'80mm' | '58mm'>('80mm');

  if (!isOpen || !order) return null;

  const handlePrint = () => {
    posAudio.playCashRegister();
    window.print();
  };

  const grossTotal = order.total || 0;
  const netAmount = order.subtotal || Math.round((grossTotal / 1.18) * 100) / 100;
  const vat16 = order.vat16 || Math.round((netAmount * 0.16) * 100) / 100;
  const cateringLevy2 = order.cateringLevy2 || Math.round((netAmount * 0.02) * 100) / 100;
  const kraControlCode = order.kraControlCode || `KRA-ETR-${order.orderNumber.replace('ORD-', '')}89`;
  const mpesaRef = order.mpesaCode || 'SK92KL8491';

  // WhatsApp text formulation
  const getWhatsAppReceipt = () => {
    const itemsList = order.items.map(i => `• ${i.quantity}x ${i.name} = KSh ${(i.quantity * i.price).toLocaleString()}`).join('\n');
    return `🧾 *${settings.restaurantName} - DIGITAL RECEIPT*\n` +
      `📍 ${settings.branch} | 📞 ${settings.telephone}\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `📋 *Invoice:* #${order.orderNumber}\n` +
      `🍽️ *Table:* ${order.table} | 👤 Waiter: ${order.waiterName}\n` +
      `🕒 *Time:* ${new Date(order.createdAt).toLocaleString()}\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `${itemsList}\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `Taxable Base: KSh ${netAmount.toLocaleString()}\n` +
      `16% VAT: KSh ${vat16.toLocaleString()}\n` +
      `2% Catering Levy: KSh ${cateringLevy2.toLocaleString()}\n` +
      `*TOTAL PAID: KSh ${grossTotal.toLocaleString()}*\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `✅ *Payment:* ${order.paymentMethod ? order.paymentMethod.toUpperCase() : 'M-PESA'}\n` +
      `🔑 *M-Pesa Ref:* ${mpesaRef}\n` +
      `🏛️ *KRA PIN:* ${settings.kraPin}\n` +
      `🔍 *KRA Control:* ${kraControlCode}\n` +
      `━━━━━━━━━━━━━━━━━━\n` +
      `_Asante sana kwa kuja! Karibu tena ${settings.restaurantName}!_`;
  };

  const handleWhatsAppSend = () => {
    const text = encodeURIComponent(getWhatsAppReceipt());
    const phone = order.customerPhone ? order.customerPhone.replace(/[^0-9]/g, '') : '';
    const url = phone ? `https://wa.me/${phone}?text=${text}` : `https://wa.me/?text=${text}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(getWhatsAppReceipt());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const text = getWhatsAppReceipt();
    const element = document.createElement('a');
    const file = new Blob([text], { type: 'text/plain;charset=utf-8' });
    element.href = URL.createObjectURL(file);
    element.download = `Receipt_${order.orderNumber}.txt`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl max-w-xl w-full my-6 overflow-hidden shadow-2xl flex flex-col animate-in fade-in zoom-in-95 duration-150">
        
        {/* Modal Toolbar */}
        <div className="p-4 border-b border-neutral-800 flex items-center justify-between bg-neutral-950">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-neutral-100">KRA ETR Digital Receipt</span>
            <span className="text-neutral-500">·</span>
            <span className="text-xs font-mono text-emerald-400">#{order.orderNumber}</span>
          </div>

          <div className="flex items-center gap-2">
            {/* Paper Width Selector */}
            <div className="flex items-center bg-neutral-900 border border-neutral-800 rounded p-0.5 text-[11px] font-mono">
              <button
                onClick={() => setReceiptWidth('80mm')}
                className={`px-2 py-0.5 rounded transition-colors ${
                  receiptWidth === '80mm' ? 'bg-neutral-800 text-emerald-400 font-bold' : 'text-neutral-400'
                }`}
              >
                80mm
              </button>
              <button
                onClick={() => setReceiptWidth('58mm')}
                className={`px-2 py-0.5 rounded transition-colors ${
                  receiptWidth === '58mm' ? 'bg-neutral-800 text-emerald-400 font-bold' : 'text-neutral-400'
                }`}
              >
                58mm
              </button>
            </div>

            <button
              onClick={onClose}
              className="text-neutral-400 hover:text-neutral-200 transition-colors p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Action Bar */}
        <div className="p-3 bg-neutral-950/70 border-b border-neutral-800 grid grid-cols-4 gap-2 text-xs">
          <button
            onClick={handlePrint}
            className="py-2 px-3 rounded-md bg-emerald-600 hover:bg-emerald-500 text-neutral-950 font-bold flex items-center justify-center gap-1.5 transition-colors shadow"
          >
            <Printer className="w-3.5 h-3.5" />
            Print Roll
          </button>

          <button
            onClick={handleWhatsAppSend}
            className="py-2 px-3 rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-medium flex items-center justify-center gap-1.5 transition-colors border border-neutral-700/60"
          >
            <Share2 className="w-3.5 h-3.5 text-emerald-400" />
            WhatsApp
          </button>

          <button
            onClick={handleDownload}
            className="py-2 px-3 rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-medium flex items-center justify-center gap-1.5 transition-colors border border-neutral-700/60"
          >
            <Download className="w-3.5 h-3.5 text-neutral-300" />
            Save File
          </button>

          <button
            onClick={handleCopy}
            className="py-2 px-3 rounded-md bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-medium flex items-center justify-center gap-1.5 transition-colors border border-neutral-700/60"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-neutral-300" />}
            {copied ? 'Copied!' : 'Copy'}
          </button>
        </div>

        {/* Thermal Receipt Paper Roll Viewport */}
        <div className="p-6 bg-neutral-950 flex justify-center max-h-[520px] overflow-y-auto">
          
          <div
            id="thermal-receipt-print-area"
            className={`bg-white text-neutral-900 p-6 shadow-2xl font-mono text-xs select-text border border-neutral-300 rounded-sm relative ${
              receiptWidth === '80mm' ? 'w-[340px]' : 'w-[280px]'
            }`}
          >
            {/* Top Paper Tear Indicator */}
            <div className="text-center border-b-2 border-dashed border-neutral-400 pb-3 mb-3">
              <h2 className="font-bold text-sm tracking-wide text-neutral-950">
                {settings.restaurantName}
              </h2>
              <p className="text-[11px] text-neutral-600 mt-0.5">{settings.branch}</p>
              <p className="text-[11px] text-neutral-600">Tel: {settings.telephone}</p>
              <div className="pt-1.5 text-[10px] text-neutral-700 space-y-0.5">
                <p>KRA PIN: <span className="font-semibold">{settings.kraPin}</span></p>
                <p>ETR SERIAL: <span className="font-semibold">{settings.etrSerial}</span></p>
                <p className="font-bold text-neutral-900 uppercase">KENYA TAX INVOICE (ETR)</p>
              </div>
            </div>

            {/* Invoice Meta */}
            <div className="text-[11px] border-b border-dashed border-neutral-400 pb-2 mb-2 space-y-1">
              <div className="flex justify-between">
                <span>INVOICE: #{order.orderNumber}</span>
                <span>TABLE: {order.table}</span>
              </div>
              <div className="flex justify-between">
                <span>WAITER: {order.waiterName}</span>
                <span>{new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
              <div className="text-[10px] text-neutral-500">
                DATE: {new Date(order.createdAt).toLocaleDateString()}
              </div>
            </div>

            {/* Table Items Header */}
            <div className="flex justify-between text-[11px] font-bold border-b border-neutral-800 pb-1 mb-2">
              <span>QTY ITEM</span>
              <span>KSH</span>
            </div>

            {/* Item Rows */}
            <div className="space-y-1.5 text-[11px] border-b border-dashed border-neutral-400 pb-3 mb-2">
              {order.items.map((item, idx) => (
                <div key={idx} className="flex justify-between items-start">
                  <div className="pr-2 leading-tight">
                    <span>{item.quantity}x {item.name}</span>
                    {item.notes && (
                      <p className="text-[9px] text-neutral-600 italic">*{item.notes}</p>
                    )}
                  </div>
                  <span className="font-semibold tabular-nums shrink-0">
                    {(item.quantity * item.price).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>

            {/* Taxes & Totals */}
            <div className="text-[11px] space-y-1 border-b-2 border-neutral-800 pb-2 mb-2">
              <div className="flex justify-between text-neutral-600">
                <span>Taxable Amount (Excl. Tax):</span>
                <span className="tabular-nums">KSh {netAmount.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span>16% V.A.T. (Kenya):</span>
                <span className="tabular-nums">KSh {vat16.toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-neutral-600">
                <span>2% Catering Levy:</span>
                <span className="tabular-nums">KSh {cateringLevy2.toLocaleString()}</span>
              </div>
              <div className="flex justify-between font-bold text-sm text-neutral-950 pt-1 border-t border-neutral-300">
                <span>TOTAL PAYABLE:</span>
                <span className="tabular-nums">KSh {grossTotal.toLocaleString()}</span>
              </div>
            </div>

            {/* Payment Method & Safaricom Ref */}
            <div className="text-center text-[11px] border-b border-dashed border-neutral-400 pb-2 mb-2 space-y-0.5">
              <p className="font-bold text-emerald-800 uppercase">
                PAID VIA {order.paymentMethod ? order.paymentMethod.replace('_', ' ').toUpperCase() : 'M-PESA'}
              </p>
              {order.mpesaCode && (
                <>
                  <p className="font-bold tracking-wider text-neutral-900">
                    M-PESA REF: {order.mpesaCode}
                  </p>
                  {order.customerPhone && (
                    <p className="text-[10px] text-neutral-600">
                      PHONE: {order.customerPhone.slice(0, 6)}****{order.customerPhone.slice(-3)}
                    </p>
                  )}
                  <p className="text-[10px] text-emerald-700 font-semibold">
                    CONFIRMED BY SAFARICOM DARAJA
                  </p>
                </>
              )}
            </div>

            {/* KRA QR Verification Code Box */}
            <div className="text-center py-2 space-y-1.5 border-b border-dashed border-neutral-400">
              {/* Authentic Styled SVG QR Code Simulation */}
              <div className="w-24 h-24 mx-auto bg-neutral-950 p-2 rounded-sm flex items-center justify-center">
                <svg viewBox="0 0 100 100" className="w-full h-full fill-white">
                  <path d="M0,0 h30 v30 h-30 z M40,0 h20 v10 h-20 z M70,0 h30 v30 h-30 z M10,10 h10 v10 h-10 z M80,10 h10 v10 h-10 z M0,40 h10 v20 h-10 z M20,40 h20 v20 h-20 z M50,40 h20 v10 h-20 z M80,40 h20 v10 h-20 z M0,70 h30 v30 h-30 z M10,80 h10 v10 h-10 z M40,70 h20 v10 h-20 z M70,70 h10 v10 h-10 z M90,70 h10 v30 h-10 z M50,90 h20 v10 h-20 z M70,90 h10 v10 h-10 z" />
                </svg>
              </div>
              <p className="text-[10px] text-neutral-700 font-semibold">
                KRA CONTROL CODE: {kraControlCode}
              </p>
              <p className="text-[9px] text-neutral-500">
                Scan QR or verify at itax.kra.go.ke
              </p>
            </div>

            {/* Swahili Warm Farewell */}
            <div className="pt-2 text-center text-[10px] space-y-0.5 text-neutral-700">
              <p className="font-bold">ASANTE SANA KWA KUTUTEMBELEA!</p>
              <p className="italic">KARIBU TENA / WELCOME AGAIN</p>
              <p className="text-[9px] text-neutral-400 pt-1">SimbaPOS · Powered by Python</p>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
