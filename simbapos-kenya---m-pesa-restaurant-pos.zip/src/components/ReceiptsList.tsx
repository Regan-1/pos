import React, { useState } from 'react';
import { Order, RestaurantSettings } from '../types';
import { Receipt, Search, Printer, Share2, Download, Eye, Smartphone, DollarSign, Calendar } from 'lucide-react';

interface ReceiptsListProps {
  orders: Order[];
  settings: RestaurantSettings;
  onOpenReceiptModal: (order: Order) => void;
}

export const ReceiptsList: React.FC<ReceiptsListProps> = ({
  orders,
  settings,
  onOpenReceiptModal
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterMethod, setFilterMethod] = useState<'all' | 'mpesa' | 'cash'>('all');

  const paidOrders = orders.filter(o => o.status === 'paid');

  const filtered = paidOrders.filter(o => {
    const matchesSearch = o.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      o.table.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (o.mpesaCode && o.mpesaCode.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (o.customerPhone && o.customerPhone.includes(searchTerm)) ||
      o.waiterName.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesMethod = filterMethod === 'all' ||
      (filterMethod === 'mpesa' && (o.paymentMethod === 'mpesa_stk' || o.paymentMethod === 'mpesa_c2b')) ||
      (filterMethod === 'cash' && o.paymentMethod === 'cash');

    return matchesSearch && matchesMethod;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      
      {/* Top Header */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-neutral-100 flex items-center gap-2">
            <Receipt className="w-5 h-5 text-emerald-400" />
            KRA ETR Receipts & Digital Invoices Archive
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Search, reprint 80mm thermal paper receipts, dispatch via WhatsApp, or verify KRA control codes.
          </p>
        </div>

        {/* Search & Filters */}
        <div className="flex items-center gap-2 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search receipt #, M-Pesa code, table..."
              className="w-full pl-9 pr-3 py-1.5 bg-neutral-950 border border-neutral-800 rounded text-xs text-neutral-100 placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="flex items-center gap-1 p-0.5 bg-neutral-950 border border-neutral-800 rounded text-xs">
            <button
              onClick={() => setFilterMethod('all')}
              className={`px-2.5 py-1 rounded transition-colors ${
                filterMethod === 'all' ? 'bg-neutral-800 text-emerald-400 font-bold' : 'text-neutral-400'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilterMethod('mpesa')}
              className={`px-2.5 py-1 rounded transition-colors ${
                filterMethod === 'mpesa' ? 'bg-neutral-800 text-emerald-400 font-bold' : 'text-neutral-400'
              }`}
            >
              M-Pesa
            </button>
            <button
              onClick={() => setFilterMethod('cash')}
              className={`px-2.5 py-1 rounded transition-colors ${
                filterMethod === 'cash' ? 'bg-neutral-800 text-emerald-400 font-bold' : 'text-neutral-400'
              }`}
            >
              Cash
            </button>
          </div>
        </div>
      </div>

      {/* Receipts Table */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-neutral-950 border-b border-neutral-800 text-neutral-400 font-mono">
              <tr>
                <th className="py-3 px-4 font-normal">Invoice #</th>
                <th className="py-3 px-4 font-normal">Date & Time</th>
                <th className="py-3 px-4 font-normal">Table</th>
                <th className="py-3 px-4 font-normal">Waiter</th>
                <th className="py-3 px-4 font-normal">Payment Method</th>
                <th className="py-3 px-4 font-normal">M-Pesa Ref</th>
                <th className="py-3 px-4 font-normal">KRA ETR Code</th>
                <th className="py-3 px-4 font-normal text-right">Amount (KSh)</th>
                <th className="py-3 px-4 font-normal text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-neutral-500">
                    No receipts found. Complete orders on the POS terminal to generate digital receipts.
                  </td>
                </tr>
              ) : (
                filtered.map(order => (
                  <tr key={order.id} className="hover:bg-neutral-800/40 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-neutral-200">
                      #{order.orderNumber}
                    </td>
                    <td className="py-3 px-4 text-neutral-400 font-mono text-[11px]">
                      {new Date(order.createdAt).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-neutral-300 font-medium">
                      {order.table}
                    </td>
                    <td className="py-3 px-4 text-neutral-300">
                      {order.waiterName}
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-mono text-[11px] text-emerald-400 uppercase">
                        {order.paymentMethod ? order.paymentMethod.replace('_', ' ') : 'M-PESA'}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-neutral-200">
                      {order.mpesaCode || '-'}
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-neutral-400">
                      {order.kraControlCode || `KRA-ETR-${order.orderNumber.replace('ORD-', '')}89`}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold tabular-nums text-emerald-400 text-sm">
                      KSh {order.total.toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => onOpenReceiptModal(order)}
                        className="py-1 px-2.5 rounded bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium inline-flex items-center gap-1 transition-colors border border-neutral-700"
                      >
                        <Eye className="w-3.5 h-3.5 text-emerald-400" />
                        Print / View
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
