import React, { useState } from 'react';
import { StaffMember } from '../types';
import { Users, UserPlus, Clock, Award, Shield, Phone, KeyRound, CheckCircle, PauseCircle, LogOut } from 'lucide-react';

interface StaffManagementProps {
  staffList: StaffMember[];
  currentStaff: StaffMember;
  onUpdateShift: (staffId: string, action: 'clock_in' | 'clock_out' | 'break') => void;
  onAddStaff: (newStaff: Partial<StaffMember>) => void;
  onSelectCurrentStaff: (staff: StaffMember) => void;
}

export const StaffManagement: React.FC<StaffManagementProps> = ({
  staffList,
  currentStaff,
  onUpdateShift,
  onAddStaff,
  onSelectCurrentStaff
}) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newStaff, setNewStaff] = useState({
    name: '',
    phone: '07',
    role: 'waiter' as StaffMember['role'],
    pin: '1234',
    commissionRate: 2.5
  });

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStaff.name.trim()) return;

    onAddStaff(newStaff);
    setShowAddModal(false);
    setNewStaff({
      name: '',
      phone: '07',
      role: 'waiter',
      pin: '1234',
      commissionRate: 2.5
    });
  };

  const getStatusBadge = (status: StaffMember['status']) => {
    switch (status) {
      case 'active':
        return <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">On Duty</span>;
      case 'on_break':
        return <span className="text-[11px] font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">On Break</span>;
      case 'clocked_out':
        return <span className="text-[11px] font-mono text-neutral-400 bg-neutral-800 px-2 py-0.5 rounded border border-neutral-700">Clocked Out</span>;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
      
      {/* Top Header */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-lg p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-neutral-100 flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-400" />
            Staff Management, Shifts & Commissions
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Monitor restaurant team shifts, commission payouts, and active cashiers/waiters.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="py-2 px-3.5 bg-emerald-600 hover:bg-emerald-500 text-neutral-950 font-bold text-xs rounded-md flex items-center gap-1.5 transition-colors shadow"
        >
          <UserPlus className="w-3.5 h-3.5" />
          Add Staff Member
        </button>
      </div>

      {/* Staff Roster Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {staffList.map(member => {
          const isCurrent = member.id === currentStaff.id;
          const commissionEarned = Math.round(member.totalSalesKSh * (member.commissionRate / 100));

          return (
            <div
              key={member.id}
              className={`bg-neutral-900 border rounded-lg p-5 flex flex-col justify-between transition-all ${
                isCurrent ? 'border-emerald-500/60 shadow-lg shadow-emerald-950/20' : 'border-neutral-800'
              }`}
            >
              <div>
                {/* Header row */}
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm text-neutral-100">{member.name}</h4>
                      {isCurrent && (
                        <span className="text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                          Active Terminal User
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-neutral-400 capitalize mt-0.5">
                      {member.role} · {member.phone}
                    </p>
                  </div>
                  {getStatusBadge(member.status)}
                </div>

                {/* Performance & Shifts info */}
                <div className="mt-4 pt-3 border-t border-neutral-800/80 space-y-2 text-xs">
                  <div className="flex justify-between text-neutral-400">
                    <span>Shift Clock-In:</span>
                    <span className="font-mono text-neutral-200">{member.lastClockIn || '08:00 AM'}</span>
                  </div>
                  <div className="flex justify-between text-neutral-400">
                    <span>Tables Served:</span>
                    <span className="font-mono font-bold text-neutral-200">{member.tablesServed}</span>
                  </div>
                  <div className="flex justify-between text-neutral-400">
                    <span>Total Sales Generated:</span>
                    <span className="font-mono font-bold text-emerald-400 tabular-nums">
                      KSh {member.totalSalesKSh.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-neutral-400">
                    <span>Commission ({member.commissionRate}%):</span>
                    <span className="font-mono font-bold text-sky-400 tabular-nums">
                      KSh {commissionEarned.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Controls */}
              <div className="mt-5 pt-3 border-t border-neutral-800 flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  {member.status !== 'active' ? (
                    <button
                      onClick={() => onUpdateShift(member.id, 'clock_in')}
                      title="Clock In"
                      className="p-1.5 bg-emerald-950 text-emerald-400 hover:bg-emerald-900 border border-emerald-800 rounded text-xs flex items-center gap-1"
                    >
                      <CheckCircle className="w-3.5 h-3.5" />
                      Clock In
                    </button>
                  ) : (
                    <>
                      <button
                        onClick={() => onUpdateShift(member.id, 'break')}
                        title="Take Break"
                        className="p-1.5 bg-amber-950 text-amber-400 hover:bg-amber-900 border border-amber-800 rounded text-xs flex items-center gap-1"
                      >
                        <PauseCircle className="w-3.5 h-3.5" />
                        Break
                      </button>
                      <button
                        onClick={() => onUpdateShift(member.id, 'clock_out')}
                        title="Clock Out"
                        className="p-1.5 bg-neutral-800 text-neutral-300 hover:bg-neutral-700 border border-neutral-700 rounded text-xs flex items-center gap-1"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        Clock Out
                      </button>
                    </>
                  )}
                </div>

                {!isCurrent && (
                  <button
                    onClick={() => onSelectCurrentStaff(member)}
                    className="py-1 px-2.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 text-xs font-medium rounded border border-neutral-700 transition-colors"
                  >
                    Switch to {member.name.split(' ')[0]}
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Staff Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <form
            onSubmit={handleAddSubmit}
            className="bg-neutral-900 border border-neutral-800 rounded-lg p-6 max-w-md w-full space-y-4 shadow-2xl"
          >
            <h3 className="font-bold text-sm text-neutral-100 flex items-center gap-2">
              <UserPlus className="w-4 h-4 text-emerald-400" />
              Register New Restaurant Staff
            </h3>

            <div className="space-y-1 text-xs">
              <label className="text-neutral-300 font-medium">Full Name</label>
              <input
                type="text"
                required
                value={newStaff.name}
                onChange={(e) => setNewStaff({ ...newStaff, name: e.target.value })}
                placeholder="e.g., Janet Achieng"
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded text-neutral-100 focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="space-y-1">
                <label className="text-neutral-300 font-medium">Phone Number</label>
                <input
                  type="text"
                  required
                  value={newStaff.phone}
                  onChange={(e) => setNewStaff({ ...newStaff, phone: e.target.value })}
                  placeholder="07XXXXXXXX"
                  className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded text-neutral-100 font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-neutral-300 font-medium">Role</label>
                <select
                  value={newStaff.role}
                  onChange={(e) => setNewStaff({ ...newStaff, role: e.target.value as any })}
                  className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded text-neutral-100 capitalize focus:outline-none focus:border-emerald-500"
                >
                  <option value="waiter">Waiter</option>
                  <option value="cashier">Cashier</option>
                  <option value="chef">Chef / Kitchen</option>
                  <option value="manager">Manager</option>
                  <option value="admin">Administrator</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="space-y-1">
                <label className="text-neutral-300 font-medium">4-Digit Security PIN</label>
                <input
                  type="password"
                  maxLength={4}
                  required
                  value={newStaff.pin}
                  onChange={(e) => setNewStaff({ ...newStaff, pin: e.target.value })}
                  placeholder="1234"
                  className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded text-neutral-100 font-mono tracking-widest focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="space-y-1">
                <label className="text-neutral-300 font-medium">Commission Rate (%)</label>
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="20"
                  value={newStaff.commissionRate}
                  onChange={(e) => setNewStaff({ ...newStaff, commissionRate: parseFloat(e.target.value) || 0 })}
                  className="w-full px-3 py-2 bg-neutral-950 border border-neutral-800 rounded text-neutral-100 font-mono focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-3 border-t border-neutral-800">
              <button
                type="button"
                onClick={() => setShowAddModal(false)}
                className="px-3 py-1.5 text-xs text-neutral-400 hover:text-neutral-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 text-xs bg-emerald-600 hover:bg-emerald-500 text-neutral-950 font-bold rounded"
              >
                Save Staff
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};
