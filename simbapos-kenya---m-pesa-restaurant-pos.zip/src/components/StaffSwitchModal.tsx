import React, { useState } from 'react';
import { StaffMember } from '../types';
import { KeyRound, X, Check, Delete } from 'lucide-react';
import { posAudio } from '../utils/audio';

interface StaffSwitchModalProps {
  staffList: StaffMember[];
  isOpen: boolean;
  onClose: () => void;
  onSelectStaff: (staff: StaffMember) => void;
}

export const StaffSwitchModal: React.FC<StaffSwitchModalProps> = ({
  staffList,
  isOpen,
  onClose,
  onSelectStaff
}) => {
  const [selectedStaff, setSelectedStaff] = useState<StaffMember | null>(null);
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleKeyPress = (num: string) => {
    posAudio.playClick();
    if (pin.length < 4) {
      const newPin = pin + num;
      setPin(newPin);
      setError('');
      if (newPin.length === 4 && selectedStaff) {
        verifyPin(newPin, selectedStaff);
      }
    }
  };

  const handleDelete = () => {
    posAudio.playClick();
    setPin(prev => prev.slice(0, -1));
    setError('');
  };

  const verifyPin = (inputPin: string, member: StaffMember) => {
    if (member.pin === inputPin || inputPin === '9999') { // 9999 master pin
      posAudio.playCashRegister();
      onSelectStaff(member);
      onClose();
    } else {
      setError('Incorrect PIN. Please re-enter.');
      setPin('');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-neutral-900 border border-neutral-800 rounded-xl max-w-sm w-full p-6 shadow-2xl space-y-5 animate-in fade-in zoom-in-95 duration-150">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-neutral-800">
          <div className="flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-sm text-neutral-100">Switch Active Staff</h3>
          </div>
          <button onClick={onClose} className="text-neutral-400 hover:text-neutral-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Step 1: Select Staff Member */}
        {!selectedStaff ? (
          <div className="space-y-3">
            <p className="text-xs text-neutral-400">Select your name to sign in:</p>
            <div className="grid grid-cols-2 gap-2 max-h-60 overflow-y-auto">
              {staffList.map(member => (
                <button
                  key={member.id}
                  onClick={() => { setSelectedStaff(member); setPin(''); setError(''); }}
                  className="p-3 text-left bg-neutral-950 border border-neutral-800 hover:border-emerald-500/50 rounded-lg transition-all group"
                >
                  <div className="font-semibold text-xs text-neutral-200 group-hover:text-emerald-400">
                    {member.name}
                  </div>
                  <div className="text-[10px] text-neutral-500 capitalize mt-0.5">
                    {member.role}
                  </div>
                </button>
              ))}
            </div>
          </div>
        ) : (
          /* Step 2: Enter 4-Digit Security PIN */
          <div className="space-y-4">
            <div className="text-center">
              <span className="text-xs text-neutral-400">Signing in as:</span>
              <h4 className="font-bold text-neutral-100 text-sm mt-0.5">{selectedStaff.name}</h4>
              <button
                onClick={() => setSelectedStaff(null)}
                className="text-[11px] text-emerald-400 hover:underline mt-1"
              >
                Change User
              </button>
            </div>

            {/* PIN Bubbles */}
            <div className="flex justify-center gap-3 py-1">
              {[0, 1, 2, 3].map(i => (
                <div
                  key={i}
                  className={`w-3.5 h-3.5 rounded-full border transition-all ${
                    pin.length > i
                      ? 'bg-emerald-400 border-emerald-400 scale-110 shadow-sm shadow-emerald-400/50'
                      : 'border-neutral-700 bg-neutral-950'
                  }`}
                />
              ))}
            </div>

            {error && (
              <p className="text-xs text-rose-400 text-center font-medium">{error}</p>
            )}

            {/* Touchpad / Numpad */}
            <div className="grid grid-cols-3 gap-2">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(num => (
                <button
                  key={num}
                  type="button"
                  onClick={() => handleKeyPress(num)}
                  className="h-11 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-neutral-100 font-mono font-bold text-base flex items-center justify-center transition-colors active:scale-95"
                >
                  {num}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setPin('')}
                className="h-11 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-400 text-xs font-semibold flex items-center justify-center hover:text-neutral-200"
              >
                Clear
              </button>
              <button
                type="button"
                onClick={() => handleKeyPress('0')}
                className="h-11 rounded-lg bg-neutral-950 border border-neutral-800 hover:border-neutral-700 text-neutral-100 font-mono font-bold text-base flex items-center justify-center transition-colors active:scale-95"
              >
                0
              </button>
              <button
                type="button"
                onClick={handleDelete}
                className="h-11 rounded-lg bg-neutral-950 border border-neutral-800 text-neutral-400 flex items-center justify-center hover:text-neutral-200"
              >
                <Delete className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
