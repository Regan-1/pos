export interface MenuItem {
  id: string;
  name: string;
  swahiliName?: string;
  category: 'choma' | 'swahili' | 'traditional' | 'bites' | 'drinks';
  price: number;
  preparationTime: string;
  inStock: boolean;
  description: string;
  image?: string;
}

export interface StaffMember {
  id: string;
  name: string;
  phone: string;
  role: 'waiter' | 'cashier' | 'chef' | 'manager' | 'admin';
  pin: string;
  status: 'active' | 'on_break' | 'clocked_out';
  commissionRate: number; // in percentage e.g. 2.5%
  totalSalesKSh: number;
  tablesServed: number;
  lastClockIn?: string;
}

export interface OrderItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  notes?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  table: string;
  waiterId: string;
  waiterName: string;
  status: 'pending' | 'preparing' | 'ready' | 'served' | 'paid';
  items: OrderItem[];
  subtotal: number;
  vat16: number;
  cateringLevy2: number;
  total: number;
  paymentMethod?: 'mpesa_stk' | 'mpesa_c2b' | 'cash' | 'card';
  mpesaCode?: string;
  customerPhone?: string;
  kraControlCode?: string;
  createdAt: string;
  paidAt?: string;
}

export interface RestaurantSettings {
  restaurantName: string;
  tagline: string;
  branch: string;
  telephone: string;
  kraPin: string;
  etrSerial: string;
  mpesaShortcode: string;
  mpesaTill: string;
  mpesaPaybill: string;
  mpesaPasskey: string;
  mpesaConsumerKey: string;
  mpesaConsumerSecret: string;
  environment: 'sandbox' | 'production';
  vatRate: number;
  cateringLevyRate: number;
}

export interface MpesaSTKResponse {
  MerchantRequestID: string;
  CheckoutRequestID: string;
  ResponseCode: string;
  ResponseDescription: string;
  CustomerMessage: string;
  simulatedReceipt?: string;
}
